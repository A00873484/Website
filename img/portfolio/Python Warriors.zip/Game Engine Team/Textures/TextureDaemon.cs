﻿using Game_Engine_Team.Actors;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Engine_Team.Texture
{

    public enum WallType
    {
        Stone0, Stone1, Stone2, Stone3,
        Rock0, Rock1, Rock2, Rock3,
        Quarry0, Quarry1, Quarry2, Quarry3,
        ReinforcedQuarry0, ReinforcedQuarry1, ReinforcedQuarry2, ReinforcedQuarry3
    }

    public enum FloorType
    {
        Stone0, Stone1, Stone2,
        Wood0, Wood1, Wood2
    }

    public enum PitType
    {
        Empty0, Empty1, Empty2,
        Ice0, Ice1, Ice2,
        Water0, Water1, Water2,
        Acid0, Acid1, Acid2,
        RoughLava, RoughWater, RoughAcid
    }

    public enum PlayerType
    {
        Rogue, Mage, Warrior,
    }

    public enum EffectType
    {
        Shuriken, Sleep, FireLarge, FireSmall, FireBall, Waypoint
    }

    public enum VectorType
    {
        RedBeam
    }

    public enum SpriteType
    {
        FireDemon,
        SnakeBrownLarge,
        Beholder,
    }

    public enum WeaponType
    {
        Assassin_Dagger, Demon_Edge, Iron_Sword, 
        Magic_Stick, Plastic_Knife, Shiv,
        Simple_Stick, Stick_Of_Truth, Toy_Sword
    }

    public enum HelmetType
    {
        Assassin_Mask, Bandana, Cooking_Pot,
        Demon_Horns, Dunce_Cap, Fake_Crown,
        Feathered_Hat, Iron_Cap, Wizards_Hat
    }

    public enum ShirtType
    {
        Assassin_Cloak, Demon_Breastplate, Elven_Cloak,
        Gandalfs_Robes, Iron_Chestplate, Jean_Jacket,
        Leather_Shirt, Magic_Clothes, T_Shirt
    }

    public enum PantsType
    {
        Assassin_Tights, Demon_Chausers, Hot_Pants,
        Iron_Leggings, Jeans, Leather_Tights,
        Mystic_Socks, Pants_That_Must_Not_Be_Named, PeterPan_Tights
    }

    public class Textures
    {
        private static Textures instance;

        public static void Inititialize( ContentManager contentManager )
        {
            var loader = new AssetLoader( contentManager );
            instance = new Textures( loader );
        }

        private Textures( AssetLoader loader )
        {
            walls[ WallType.Stone0 ] = loader.GetWallTexture( 0, 1 );
            walls[ WallType.Stone1 ] = loader.GetWallTexture( 0, 2 );
            walls[ WallType.Stone2 ] = loader.GetWallTexture( 0, 3 );
            walls[ WallType.Stone3 ] = loader.GetWallTexture( 0, 4 );

            walls[ WallType.Rock0 ] = loader.GetWallTexture( 1, 5 );
            walls[ WallType.Rock1 ] = loader.GetWallTexture( 1, 6 );
            walls[ WallType.Rock2 ] = loader.GetWallTexture( 1, 7 );
            walls[ WallType.Rock3 ] = loader.GetWallTexture( 1, 8 );

            walls[ WallType.Quarry0 ] = loader.GetWallTexture( 0, 5 );
            walls[ WallType.Quarry1 ] = loader.GetWallTexture( 0, 6 );
            walls[ WallType.Quarry2 ] = loader.GetWallTexture( 0, 7 );
            walls[ WallType.Quarry3 ] = loader.GetWallTexture( 0, 8 );

            walls[ WallType.ReinforcedQuarry0 ] = loader.GetWallTexture( 2, 1 );
            walls[ WallType.ReinforcedQuarry1 ] = loader.GetWallTexture( 2, 2 );
            walls[ WallType.ReinforcedQuarry2 ] = loader.GetWallTexture( 2, 3 );
            walls[ WallType.ReinforcedQuarry3 ] = loader.GetWallTexture( 2, 4 );


            floors[ FloorType.Stone0 ] = loader.GetFloorTexture( 0, 2, true );
            floors[ FloorType.Stone1 ] = loader.GetFloorTexture( 0, 3, true );
            floors[ FloorType.Stone2 ] = loader.GetFloorTexture( 0, 4, true );

            floors[ FloorType.Wood0 ] = loader.GetFloorTexture( 1, 6, true );
            floors[ FloorType.Wood1 ] = loader.GetFloorTexture( 1, 7, true );
            floors[ FloorType.Wood2 ] = loader.GetFloorTexture( 1, 8, true );

            
            foreach ( PitType type in EnumUtil.GetValues<PitType>() )
            {
                pits[ type ] = loader.GetPitTexture( 1 + (int) type );
            }


            players[ PlayerType.Rogue ] = loader.GetPlayerSprite( "Rogue" );
            players[ PlayerType.Mage ] = loader.GetPlayerSprite( "Mage" );
            players[ PlayerType.Warrior ] = loader.GetPlayerSprite( "Warrior" );


            effects[ EffectType.Shuriken ] = loader.GetAnimatedTexture( 1, 3, "Sprites/Items/Ammo" );
            effects[ EffectType.Sleep ] = loader.GetAnimatedTexture( 5, 16, "Sprites/Objects/Effect", 2 );
            effects[ EffectType.FireLarge ] = loader.GetAnimatedTexture( 1, 21, "Sprites/Objects/Effect", 2 );
            effects[ EffectType.FireSmall ] = loader.GetAnimatedTexture( 0, 21, "Sprites/Objects/Effect", 2 );
            effects[ EffectType.FireBall ] = loader.GetAnimatedTexture( 1, 24, "Sprites/Objects/Effect", 2 );
            effects[ EffectType.Waypoint ] = loader.GetAnimatedTexture( 4, 23, "Sprites/Objects/Effect", 2 );

            effects[ EffectType.FireLarge ].Tint = new Color( 255, 255, 255, 225 );
            effects[ EffectType.FireSmall ].Tint = new Color( 255, 255, 255, 225 );


            vectors[ VectorType.RedBeam ] = loader.GetVectorSprite( 0, 15, "Sprites/Objects/Effect", 2 );


            weapons[ WeaponType.Assassin_Dagger ] = loader.GetSprite( 6, 0, "Sprites/Items/LongWep" );
            weapons[ WeaponType.Demon_Edge ] = loader.GetSprite( 1, 1, "Sprites/Items/LongWep" );
            weapons[ WeaponType.Iron_Sword ] = loader.GetSprite( 2, 0, "Sprites/Items/LongWep" );
            weapons[ WeaponType.Magic_Stick ] = loader.GetSprite( 5, 0, "Sprites/Items/LongWep" );
            weapons[ WeaponType.Plastic_Knife ] = loader.GetSprite( 0, 0, "Sprites/Items/LongWep" );
            weapons[ WeaponType.Shiv ] = loader.GetSprite( 0, 1, "Sprites/Items/LongWep" );
            weapons[ WeaponType.Simple_Stick ] = loader.GetSprite( 2, 4, "Sprites/Items/LongWep" );
            weapons[ WeaponType.Stick_Of_Truth ] = loader.GetSprite( 4, 0, "Sprites/Items/LongWep" );
            weapons[ WeaponType.Toy_Sword ] = loader.GetSprite( 3, 1, "Sprites/Items/LongWep" );

            helmets[ HelmetType.Assassin_Mask ] = loader.GetSprite( 0, 2, "Sprites/Items/Armor" );
            helmets[ HelmetType.Bandana ] = loader.GetSprite( 0, 3, "Sprites/Items/Armor" );
            helmets[ HelmetType.Cooking_Pot ] = loader.GetSprite( 0, 0, "Sprites/Items/Armor" );
            helmets[ HelmetType.Demon_Horns ] = loader.GetSprite( 0, 1, "Sprites/Items/Armor" );
            helmets[ HelmetType.Dunce_Cap ] = loader.GetSprite( 2, 2, "Sprites/Items/Armor" );
            helmets[ HelmetType.Fake_Crown ] = loader.GetSprite( 1, 3, "Sprites/Items/Armor" );
            helmets[ HelmetType.Feathered_Hat ] = loader.GetSprite( 2, 0, "Sprites/Items/Armor" );
            helmets[ HelmetType.Iron_Cap ] = loader.GetSprite( 3, 0, "Sprites/Items/Armor" );
            helmets[ HelmetType.Wizards_Hat ] = loader.GetSprite( 1, 2, "Sprites/Items/Armor" );

            shirts[ ShirtType.Assassin_Cloak ] = loader.GetSprite( 6, 4, "Sprites/Items/Armor" );
            shirts[ ShirtType.Demon_Breastplate ] = loader.GetSprite( 0, 1, "Sprites/Items/Armor" );
            shirts[ ShirtType.Elven_Cloak ] = loader.GetSprite( 0, 4, "Sprites/Items/Armor" );
            shirts[ ShirtType.Gandalfs_Robes ] = loader.GetSprite( 7, 4, "Sprites/Items/Armor" );
            shirts[ ShirtType.Iron_Chestplate ] = loader.GetSprite( 2, 6, "Sprites/Items/Armor" );
            shirts[ ShirtType.Jean_Jacket ] = loader.GetSprite( 3, 7, "Sprites/Items/Armor" );
            shirts[ ShirtType.Leather_Shirt ] = loader.GetSprite( 0, 7, "Sprites/Items/Armor" );
            shirts[ ShirtType.Magic_Clothes ] = loader.GetSprite( 2, 7, "Sprites/Items/Armor" );
            shirts[ ShirtType.T_Shirt ] = loader.GetSprite( 7, 7, "Sprites/Items/Armor" );

            pants[ PantsType.Assassin_Tights ] = loader.GetSprite( 0, 1, "Sprites/Items/Armor" );
            pants[ PantsType.Demon_Chausers ] = loader.GetSprite( 1, 0, "Sprites/Items/Armor" );
            pants[ PantsType.Hot_Pants ] = loader.GetSprite( 0, 0, "Sprites/Items/Armor" );
            pants[ PantsType.Iron_Leggings ] = loader.GetSprite( 1, 1, "Sprites/Items/Armor" );
            pants[ PantsType.Jeans ] = loader.GetSprite( 6, 0, "Sprites/Items/Armor" );
            pants[ PantsType.Leather_Tights ] = loader.GetSprite( 5, 0, "Sprites/Items/Armor" );
            pants[ PantsType.Mystic_Socks ] = loader.GetSprite( 3, 0, "Sprites/Items/Armor" );
            pants[ PantsType.Pants_That_Must_Not_Be_Named ] = loader.GetSprite( 7, 0, "Sprites/Items/Armor" );
            pants[ PantsType.PeterPan_Tights ] = loader.GetSprite( 4, 0, "Sprites/Items/Armor" );


            enemies[ SpriteType.FireDemon ] = loader.GetAnimatedTexture( 0, 1, "Sprites/Characters/Demon", 2 );
            enemies[ SpriteType.SnakeBrownLarge ] = loader.GetAnimatedTexture( 2, 4, "Sprites/Characters/Reptile", 2 );
            enemies[ SpriteType.Beholder ] = loader.GetAnimatedTexture( 2, 5, "Sprites/Characters/Elemental", 2 );
            //enemies[ SpriteType. ] = loader.GetAnimatedTexture( 2, 4, "Sprites/Characters/Reptile", 2 );
            //enemies[ SpriteType. ] = loader.GetAnimatedTexture( 2, 4, "Sprites/Characters/Reptile", 2 );
        }

        /// <summary>
        /// Alias for Game_Engine_Team.Actors.Enemy.Database.GetSprite.
        /// </summary>
        /// <param name="type">The enemy type whose sprite to return.</param>
        /// <returns>A non-aliasing sprite object.</returns>
        public static Sprite Get( EnemyType type )
        {
            return Enemy.Database.GetSprite( type );
        }


        private Dictionary<WallType,   WallTexture>     walls   = new Dictionary<WallType, WallTexture>();
        private Dictionary<FloorType,  FloorTexture>    floors  = new Dictionary<FloorType, FloorTexture>();
        private Dictionary<PitType,    PitTexture>      pits    = new Dictionary<PitType, PitTexture>();
        private Dictionary<SpriteType, Sprite>          enemies = new Dictionary<SpriteType, Sprite>();
        private Dictionary<PlayerType, PlayerSprite>    players = new Dictionary<PlayerType, PlayerSprite>();
        private Dictionary<EffectType, AnimatedTexture> effects = new Dictionary<EffectType, AnimatedTexture>();
        private Dictionary<VectorType, VectorSprite>    vectors = new Dictionary<VectorType, VectorSprite>();
        private Dictionary<WeaponType, Sprite>          weapons = new Dictionary<WeaponType, Sprite>();
        private Dictionary<HelmetType, Sprite>          helmets = new Dictionary<HelmetType, Sprite>();
        private Dictionary<ShirtType , Sprite>          shirts  = new Dictionary<ShirtType, Sprite>();
        private Dictionary<PantsType , Sprite>          pants   = new Dictionary<PantsType, Sprite>();


        public static WallTexture Get( WallType type )
        {
            return instance.walls[ type ].CloneSmart() as WallTexture;
        }

        public static WallType Find( WallTexture texture )
        {
            foreach ( var pair in instance.walls.ToArray() )
                if ( pair.Value == texture )
                    return pair.Key;
            
            throw new InvalidOperationException( "Texture not found." );
        }


        public static FloorTexture Get( FloorType type )
        {
            return instance.floors[ type ].CloneSmart() as FloorTexture;
        }

        public static FloorType Find( FloorTexture texture )
        {
            foreach ( var pair in instance.floors.ToArray() )
                if ( pair.Value == texture )
                    return pair.Key;

            throw new InvalidOperationException( "Texture not found." );
        }


        public static PitTexture Get( PitType type )
        {
            return instance.pits[ type ].CloneSmart() as PitTexture;
        }

        public static PitType Find( PitTexture texture )
        {
            foreach ( var pair in instance.pits.ToArray() )
                if ( pair.Value == texture )
                    return pair.Key;

            throw new InvalidOperationException( "Texture not found." );
        }


        public static Sprite Get( SpriteType type )
        {
            return instance.enemies[ type ].Spawn() as Sprite;
        }

        public static SpriteType Find( Sprite texture )
        {
            foreach ( var pair in instance.enemies.ToArray() )
                if ( pair.Value == texture )
                    return pair.Key;

            throw new InvalidOperationException( "Texture not found." );
        }


        public static PlayerSprite Get( PlayerType type )
        {
            return instance.players[ type ].Spawn() as PlayerSprite;
        }

        public static PlayerType Find( PlayerSprite texture )
        {
            foreach ( var pair in instance.players.ToArray() )
                if ( pair.Value == texture )
                    return pair.Key;

            throw new InvalidOperationException( "Texture not found." );
        }


        public static AnimatedTexture Get( EffectType type )
        {
            return instance.effects[ type ].Spawn() as AnimatedTexture;
        }

        public static EffectType Find( AnimatedTexture texture )
        {
            foreach ( var pair in instance.effects.ToArray() )
                if ( pair.Value == texture )
                    return pair.Key;

            throw new InvalidOperationException( "Texture not found." );
        }


        public static VectorSprite Get( VectorType type )
        {
            return instance.vectors[ type ].Spawn() as VectorSprite;
        }

        public static VectorType Find( VectorSprite texture )
        {
            foreach ( var pair in instance.vectors.ToArray() )
                if ( pair.Value == texture )
                    return pair.Key;

            throw new InvalidOperationException( "Texture not found." );
        }

        public static Sprite GetWeapon( WeaponType type )
        {
            return instance.weapons[ type ].Spawn() as Sprite;
        }

        public static Sprite GetHelmet( HelmetType type )
        {
            return instance.helmets[ type ].Spawn() as Sprite;
        }

        public static Sprite GetShirt( ShirtType type )
        {
            return instance.shirts[ type ].Spawn() as Sprite;
        }

        public static Sprite GetLeggings( PantsType type )
        {
            return instance.pants[ type ].Spawn() as Sprite;
        }

        public static WeaponType FindWep( Sprite texture )
        {
            foreach ( var pair in instance.weapons.ToArray() )
                if ( pair.Value == texture )
                    return pair.Key;

            throw new InvalidOperationException( "Texture not found." );
        }

    }

    public static class EnumUtil
    {
        public static IEnumerable<T> GetValues<T>()
        {
            return Enum.GetValues( typeof( T ) ).Cast<T>();
        }

        public static int GetLength<T>()
        {
            return Enum.GetValues( typeof( T ) ).Length;
        }
    }
}
