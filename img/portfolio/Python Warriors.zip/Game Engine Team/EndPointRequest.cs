﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Game_Engine_Team
{
    /// <summary>
    /// A helper class which makes web requests to the server and returns the text/json from the server.
    /// 
    /// By: Carl Kuang
    /// </summary>
    internal class EndPointRequest
    {
        /// <summary>
        /// Build the http request with the specified method.
        /// </summary>
        /// <param name="endpoint">the endpoint trying to reach</param>
        /// <param name="method">request method</param>
        /// <returns>http request</returns>
        private static HttpWebRequest BuildRequest(string endpoint, string method)
        {
            // Creates the initial HTTP request object to the server
            HttpWebRequest httpWebRequest = WebRequest.CreateHttp(endpoint);

            httpWebRequest.ContentType = "text/json";
            httpWebRequest.Method = method;

            return httpWebRequest;
        }

        public static string Get(string endpoint)
        {
            HttpWebRequest httpWebRequest = BuildRequest(endpoint, "GET");

            // Reads back and prints the response
            WebResponse httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

            string result = "";
            // Opens a stream to the response and parses the data
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                result = streamReader.ReadToEnd();
            }
            return result;
        }

        public static string Get(string endpoint, string authToken)
        {
            HttpWebRequest httpWebRequest = BuildRequest(endpoint, "GET");
            httpWebRequest.Headers.Add("X-Auth-Token", authToken);

            // Reads back and prints the response
            WebResponse httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

            string result = "";
            // Opens a stream to the response and parses the data
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                result = streamReader.ReadToEnd();
            }
            return result;
        }

        public static string Post(string endpoint, string json)
        {
            HttpWebRequest httpWebRequest = BuildRequest(endpoint, "POST");

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(json);
            }

            // Reads back the response
            HttpWebResponse httpResponse = (httpWebRequest.GetResponse() as HttpWebResponse);
            string result = "";
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                result = streamReader.ReadToEnd();
            }

            return result;
        }

        public static string Post(string endpoint, string json, string authToken)
        {
            HttpWebRequest httpWebRequest = BuildRequest(endpoint, "POST");
            httpWebRequest.Headers.Add("X-Auth-Token", authToken);

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(json);
            }

            // Reads back the response
            HttpWebResponse httpResponse = (httpWebRequest.GetResponse() as HttpWebResponse);
            string result = "";
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                result = streamReader.ReadToEnd();
            }

            return result;
        }
    }
}
