﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Game_Engine_Team.Actors;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game_Engine_Team.Equipment
{
    /// <summary>
    /// A Leggings equipment that provides defence bonuses to a character. Before this class is used
    /// the spritesheet for it needs to be loaded.
    /// 
    /// Author: Jonathan Gribble
    /// Sub-Author:
    /// 
    /// Created: Nov 15th
    /// Last Update: Nov 18th
    /// </summary>
    class Leggings : Equipment
    {

        /// <summary>
        /// The spritesheet representing Leggingss.
        /// </summary>
        public static Texture2D spritesheet;

        /// <summary>
        /// Creates the Leggings.
        /// </summary>
        /// <param name="col">The x-location of the sprite on the spritesheet.</param>
        /// <param name="row">The y-location of the sprite on the spritesheet.</param>
        public Leggings( int col, int row ) : base( col, row, spritesheet ) { }

        /// <summary>
        /// Makes sure to unequip the previous item before equipping the new one.
        /// </summary>
        /// <param name="target"></param>
        public override void Equip( Player target )
        {
            if ( target.Class != Restrictions )
                return;
            if ( target.Equipment[ EquipmentSlots.Legs ] != null )
                target.Equipment[ EquipmentSlots.Legs ].Unequip( target );
            base.Equip( target );
        }

        /// <summary>
        /// Removes the equipment from the character.
        /// </summary>
        /// <param name="target"></param>
        public override void Unequip( Player target )
        {
            target.Equipment[ EquipmentSlots.Legs ] = null;
            base.Unequip( target );
        }

        /// <summary>
        /// Creates a Leggings of the provided type.
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static Equipment CreateLeggings( Pants type )
        {
            switch ( type )
            {
                case Pants.Assassin_Tights:
                    return new Leggings( 0, 1 )
                    {
                        Dexterity = 750,
                        Defence = 550,
                        Name = "Assassin Tights",
                        Restrictions = PlayerType.Rogue,
                        Description = "These dark boots of assassination look remarkibly like boots.",
                        Sprite = Textures.GetLeggings( PantsType.Assassin_Tights ),
                        Cost = 1000
                    };
                case Pants.Demon_Chausers:
                    return new Leggings( 1, 0 )
                    {
                        Defence = 9,
                        Health = 3,
                        Name = "Demon Chausers",
                        Restrictions = PlayerType.Warrior,
                        Description = "The demon was unwilling to part with its legs, so you stole its feet instead.",
                        Sprite = Textures.GetLeggings( PantsType.Demon_Chausers ),
                        Cost = 1000
                    };
                case Pants.Hot_Pants:
                    return new Leggings( 0, 0 )
                    {
                        Defence = 3,
                        Damage = 10,
                        Name = "Hot Pants",
                        Restrictions = PlayerType.Mage,
                        Description = "These small pants are missing a leg hole, but that can be fixed easily enough.",
                        Sprite = Textures.GetLeggings( PantsType.Hot_Pants ),
                        Cost = 10
                    };
                case Pants.Iron_Leggings:
                    return new Leggings( 1, 1 )
                    {
                        Defence = 80,
                        Health = 50,
                        Name = "Iron Leggings",
                        Restrictions = PlayerType.Warrior,
                        Description = "The camrea slipped, so all you can see are the sweet boots of the Iron Leggings.",
                        Sprite = Textures.GetLeggings( PantsType.Iron_Leggings ),
                        Cost = 100
                    };
                case Pants.Jeans:
                    return new Leggings( 6, 0 )
                    {
                        Health = 5,
                        Defence = 8,
                        Name = "Jeans",
                        Restrictions = PlayerType.Warrior,
                        Description = "Black Jeans to be specific. To be precise, black jean booties.",
                        Sprite = Textures.GetLeggings( PantsType.Jeans ),
                        Cost = 10
                    };
                case Pants.Leather_Tights:
                    return new Leggings( 5, 0 )
                    {
                        Dexterity = 8,
                        Defence = 5,
                        Name = "Leather Tights",
                        Restrictions = PlayerType.Rogue,
                        Description = "These tights seem to come from the same store as the leather shirt.  Also. Boots.",
                        Sprite = Textures.GetLeggings( PantsType.Leather_Tights ),
                        Cost = 10
                    };
                case Pants.Mystic_Socks:
                    return new Leggings( 3, 0 )
                    {
                        Defence = 30,
                        Damage = 100,
                        Name = "Mystic Socks",
                        Restrictions = PlayerType.Mage,
                        Description = "These green socks have their own set of powerful arcane whiskers.",
                        Sprite = Textures.GetLeggings( PantsType.Mystic_Socks ),
                        Cost = 100
                    };
                case Pants.Pants_That_Must_Not_Be_Named:
                    return new Leggings( 7, 0 )
                    {
                        Defence = 300,
                        Damage = 1000,
                        Name = "Pants That Must Not Be Named",
                        Restrictions = PlayerType.Mage,
                        Description = "These unamed pants resemble a shoe with buckle. Don't let their appearance fool you. No one dares name these pants.",
                        Sprite = Textures.GetLeggings( PantsType.Pants_That_Must_Not_Be_Named ),
                        Cost = 1000
                    };
                case Pants.PeterPan_Tights:
                    return new Leggings( 4, 0 )
                    {
                        Defence = 50,
                        Dexterity = 80,
                        Name = "PeterPan Tights",
                        Restrictions = PlayerType.Rogue,
                        Description = "Due to copyright issues, all that can be shown of these pants are their boots.",
                        Sprite = Textures.GetLeggings( PantsType.PeterPan_Tights ),
                        Cost = 100
                    };
                default:
                    throw new ArgumentException( "The Leggings type " + type.ToString() + " does not have a switch case in the Leggings class." );
            }
        }
    }
}

