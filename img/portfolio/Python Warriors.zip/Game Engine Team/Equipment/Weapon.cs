﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Game_Engine_Team.Actors;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game_Engine_Team.Equipment
{
    /// <summary>
    /// Weapons used by the characters.
    /// 
    /// Author: Jonathan Gribble
    /// Sub-Author:
    /// 
    /// Created: Nov 15th
    /// Last Update: Nov 18th
    /// </summary>
    class Weapon : Equipment
    {
        /// <summary>
        /// The spritesheet representing Weapons.
        /// </summary>
        public static Texture2D spritesheet;


        /// <summary>
        /// Creates the Weapon.
        /// </summary>
        /// <param name="col">The x-location of the sprite on the spritesheet.</param>
        /// <param name="row">The y-location of the sprite on the spritesheet.</param>
        public Weapon( int col, int row ) : base( col, row, spritesheet ) { }

        /// <summary>
        /// Makes sure to unequip the previous item before equipping the new one.
        /// </summary>
        /// <param name="target"></param>
        public override void Equip( Player target )
        {
            if ( target.Class != Restrictions )
                return;
            if ( target.Equipment[ EquipmentSlots.Weapon ] != null )
                target.Equipment[ EquipmentSlots.Weapon ].Unequip( target );
            base.Equip( target );
        }

        /// <summary>
        /// Removes the equipment from the character.
        /// </summary>
        /// <param name="target"></param>
        public override void Unequip( Player target )
        {
            target.Equipment[ EquipmentSlots.Weapon ] = null;
            base.Unequip( target );
        }

        /// <summary>
        /// Creates a Weapon of the provided type.
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static Equipment CreateWeapon( Weapons type )
        {
            switch ( type )
            {
                case Weapons.Assassin_Dagger:
                    return new Weapon( 6, 0 )
                    {
                        Dexterity = 1400,
                        Damage = 600,
                        Restrictions = PlayerType.Rogue,
                        Name = "Assassin Dagger",
                        Description = "Pronged for your pleasure.",
                        Sprite = Textures.GetWeapon( WeaponType.Assassin_Dagger ),
                        Cost = 1500
                    };
                case Weapons.Demon_Edge:
                    return new Weapon( 1, 1 )
                    {
                        Damage = 400,
                        Health = 1150,
                        Defence = 350,
                        Restrictions = PlayerType.Warrior,
                        Name = "Demon Edge",
                        Description = "An edge made of demon bone. Excellent for boosting one's health before death.",
                        Sprite = Textures.GetWeapon( WeaponType.Demon_Edge ),
                        Cost = 1500
                    };
                case Weapons.Iron_Sword:
                    return new Weapon( 2, 1 )
                    {
                        Damage = 45,
                        Health = 110,
                        Defence = 45,
                        Restrictions = PlayerType.Warrior,
                        Name = "Iron Sword",
                        Description = "A simple sword made of iron. Can be found everywhere.",
                        Sprite = Textures.GetWeapon( WeaponType.Iron_Sword ),
                        Cost = 150
                    };
                case Weapons.Magic_Stick:
                    return new Weapon( 5, 0 )
                    {
                        Damage = 160,
                        Defence = 10,
                        Dexterity = 10,
                        Health = 10,
                        Restrictions = PlayerType.Mage,
                        Name = "Magic Stick",
                        Description = "This stick is rumoured to be magical. You see no reason to believe otherwise.",
                        Sprite = Textures.GetWeapon( WeaponType.Magic_Stick ),
                        Cost = 150
                    };
                case Weapons.Plastic_Knife:
                    return new Weapon( 0, 0 )
                    {
                        Dexterity = 14,
                        Damage = 6,
                        Restrictions = PlayerType.Rogue,
                        Name = "Plastic Knife",
                        Description = "This knife is more stick than blade.",
                        Sprite = Textures.GetWeapon( WeaponType.Plastic_Knife ),
                        Cost = 15
                    };
                case Weapons.Shiv:
                    return new Weapon( 0, 1 )
                    {
                        Dexterity = 140,
                        Damage = 60,
                        Restrictions = PlayerType.Rogue,
                        Name = "Shiv",
                        Description = "This shive still has a longer handle than blade.",
                        Sprite = Textures.GetWeapon( WeaponType.Shiv ),
                        Cost = 150
                    };
                case Weapons.Simple_Stick:
                    return new Weapon( 2, 4 )
                    {
                        Damage = 16,
                        Dexterity = 1,
                        Defence = 1,
                        Health = 1,
                        Restrictions = PlayerType.Mage,
                        Name = "Simple Stick",
                        Description = "It's a simple stick. Maybe it has magic? Probably not.",
                        Sprite = Textures.GetWeapon( WeaponType.Simple_Stick ),
                        Cost = 15
                    };
                case Weapons.Stick_Of_Truth:
                    return new Weapon( 4, 0 )
                    {
                        Damage = 1600,
                        Dexterity = 100,
                        Health = 100,
                        Defence = 100,
                        Restrictions = PlayerType.Mage,
                        Name = "Stick of Truth",
                        Description = "This stick is the truth of all. Still not magical though.",
                        Sprite = Textures.GetWeapon( WeaponType.Stick_Of_Truth ),
                        Cost = 1500
                    };
                case Weapons.Toy_Sword:
                    return new Weapon( 3, 1 )
                    {
                        Damage = 4,
                        Health = 8,
                        Defence = 8,
                        Restrictions = PlayerType.Warrior,
                        Name = "Toy Sword",
                        Description = "It may squeak everytime you hasHit something, but it's still sword-shaped.",
                        Sprite = Textures.GetWeapon( WeaponType.Toy_Sword ),
                        Cost = 15
                    };
                default:
                    throw new ArgumentException( "The Weapon type " + type.ToString() + " does not have a switch case in the Weapon class." );
            }
        }
    }
}
