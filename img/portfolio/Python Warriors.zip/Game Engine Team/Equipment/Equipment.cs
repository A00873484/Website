﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Game_Engine_Team.Texture;
using Game_Engine_Team;
using Controls;
using Game_Engine_Team.Actors;

namespace Game_Engine_Team.Equipment
{
    /// <summary>
    /// The basic equipment that can be used by the various classes. Equipment can be either
    /// weapons or armour.
    /// 
    /// Author: Jonathan Gribble
    /// Sub-Author:
    /// 
    /// Created: Nov 15th
    /// Last Update: Nov 18th
    /// </summary>
    public abstract class Equipment
    {
        public Sprite Sprite { get; protected set; }

        public String Name { get; protected set; }

        /// <summary>
        /// The defence bonus the equipment provides.
        /// </summary>
        public int Defence { get; protected set; }

        /// <summary>
        /// The damage bonus the equipment provides.
        /// </summary>
        public int Damage { get; protected set; }

        /// <summary>
        /// The health bonus the equipment provides.
        /// </summary>
        public int Health { get; protected set; }

        /// <summary>
        /// The dexterity bonus the equipment provides.
        /// </summary>
        public int Dexterity { get; protected set; }

        /// <summary>
        /// A brief description of the equipment.
        /// </summary>
        public string Description { get; protected set; }

        /// <summary>
        /// Allows drawing of the equipment in case it needs to be viewed anywhere.
        /// </summary>
        private AnimatedTexture animator;

        /// <summary>
        /// The class(es) that are allowed to use the equipment.
        /// </summary>
        public PlayerType Restrictions { get; protected set; }

        /// <summary>
        /// The XP cost to equip the equipment.
        /// </summary>
        public int Cost { get; protected set; }

        /// <summary>
        /// Creates the equipment and sets up the animator appropiately.
        /// </summary>
        /// <param name="col">The x-location of the sprite on the textures.</param>
        /// <param name="row">The y-location of the psrite on the textures.</param>
        /// <param name="textures">The textures representing the equipment.</param>
        public Equipment(int col, int row, params Texture2D[] textures)
        {
            animator = new AnimatedTexture(col, row, textures);
        }

        /// <summary>
        /// Updates the animated texture as necessary.
        /// </summary>
        /// <param name="gameTime">The gameState time being used by the gameState.</param>
        public void Update(GameTime gameTime)
        {
            animator.Update(gameTime);
        }

        /// <summary>
        /// Allows drawing of the equipment at the provided location.
        /// </summary>
        /// <param name="canvas">The spritebatch canvas used for drawing.</param>
        /// <param name="loc">The location to draw the equiment in pixel space, not next space.</param>
        public void Draw(Canvas canvas, Point loc)
        {
            if ( Sprite != null )
                canvas.Draw( Sprite, loc );
            //animator.Draw(canvas, loc, false);
        }

        /// <summary>
        /// Equips the equipment onto the target character. 
        /// </summary>
        /// <param name="target">The character to equip the equipment to.</param>
        public virtual void Equip(Player target)
        {
            target.Defense += Defence;
            //target.MaxHealth += Health;
            target.Dexterity += Dexterity;
            target.Offense += Damage;
        }

        /// <summary>
        /// Makes any necessary changes to the player when the equipment is removed.
        /// </summary>
        /// <param name="target"></param>
        public virtual void Unequip(Player target)
        {
            target.Defense -= Defence;
            //target.MaxHealth -= Health;
            target.Dexterity -= Dexterity;
            target.Offense -= Damage;
        }

        /// <summary>
        /// Creates the equipment provided.
        /// </summary>
        /// <param name="type">The type of equipment to create.</param>
        /// <returns>Returns the equipment requested.</returns>
        public static Equipment CreateEquipment(Helmets type)
        {
            return Helmet.CreateHelmet(type);
        }

        /// <summary>
        /// Creates the equipment provided.
        /// </summary>
        /// <param name="type">The type of equipment to create.</param>
        /// <returns>Returns the equipment requested.</returns>
        public static Equipment CreateEquipment(Weapons type)
        {
            return Weapon.CreateWeapon(type);
        }

        /// <summary>
        /// Creates the equipment provided.
        /// </summary>
        /// <param name="type">The type of equipment to create.</param>
        /// <returns>Returns the equipment requested.</returns>
        public static Equipment CreateEquipment(Shirts type)
        {
            return Shirt.CreateShirt(type);
        }

        /// <summary>
        /// Creates the equipment provided.
        /// </summary>
        /// <param name="type">The type of equipment to create.</param>
        /// <returns>Returns the equipment requested.</returns>
        public static Equipment CreateEquipment(Pants type)
        {
            return Leggings.CreateLeggings(type);
        }
    }

    public class Equipment2<TPlayer> where TPlayer : Player
    {

        public Stats stats;

        public void Equip( TPlayer player )
        {

        }

        public void Unequip( TPlayer player )
        {

        }

    }

    public static class PlayerExtentions
    {

        public static void Equip<TPlayer>( this TPlayer player, Equipment2<TPlayer> equipment )
            where TPlayer : Player
        {
            equipment.Equip( player );
        }

    }

}
