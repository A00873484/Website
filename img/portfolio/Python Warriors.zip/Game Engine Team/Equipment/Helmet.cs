﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Game_Engine_Team.Actors;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game_Engine_Team.Equipment
{
    /// <summary>
    /// A Helmet equipment that provides defence bonuses to a character. Before this class is used
    /// the spritesheet for it needs to be loaded.
    /// 
    /// Author: Jonathan Gribble
    /// Sub-Author:
    /// 
    /// Created: Nov 15th
    /// Last Update: Nov 18th
    /// </summary>
    class Helmet : Equipment
    {
        /// <summary>
        /// The spritesheet representing helmets.
        /// </summary>
        public static Texture2D spritesheet;

        /// <summary>
        /// Creates the helmet.
        /// </summary>
        /// <param name="col">The x-location of the sprite on the spritesheet.</param>
        /// <param name="row">The y-location of the sprite on the spritesheet.</param>
        public Helmet( int col, int row ) : base( col, row, spritesheet ) { }

        /// <summary>
        /// Makes sure to unequip the previous item before equipping the new one.
        /// </summary>
        /// <param name="target"></param>
        public override void Equip( Player target )
        {
            if ( target.Class != Restrictions )
                return;
            if ( target.Equipment[ EquipmentSlots.Helmet ] != null )
                target.Equipment[ EquipmentSlots.Helmet ].Unequip( target );
            base.Equip( target );
        }

        /// <summary>
        /// Removes the equipment from the character.
        /// </summary>
        /// <param name="target"></param>
        public override void Unequip( Player target )
        {
            target.Equipment[ EquipmentSlots.Helmet ] = null;
            base.Unequip( target );
        }

        /// <summary>
        /// Creates a helmet of the provided type.
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static Equipment CreateHelmet( Helmets type )
        {
            switch ( type )
            {
                case Helmets.Assassin_Mask:
                    return new Helmet( 0, 2 )
                    {
                        Dexterity = 750,
                        Defence = 550,
                        Name = "Assassin Mask",
                        Restrictions = PlayerType.Rogue,
                        Description = "If looks could kill, the wearer of this mask would need nothing else.",
                        Sprite = Textures.GetHelmet( HelmetType.Assassin_Mask ),
                        Cost = 1000
                    };
                case Helmets.Bandana:
                    return new Helmet( 0, 3 )
                    {
                        Dexterity = 8,
                        Defence = 5,
                        Name = "Bandana",
                        Restrictions = PlayerType.Rogue,
                        Description = "A simple bandanna noting the guild the theif belongs to.",
                        Sprite = Textures.GetHelmet( HelmetType.Bandana ),
                        Cost = 10
                    };
                case Helmets.Cooking_Pot:
                    return new Helmet( 0, 0 )
                    {
                        Health = 5,
                        Defence = 8,
                        Name = "Cooking Pot",
                        Restrictions = PlayerType.Warrior,
                        Description = "Don't be fooled. This helmet doubles as an excellent cooking utensil.",
                        Sprite = Textures.GetHelmet( HelmetType.Cooking_Pot ),
                        Cost = 10
                    };
                case Helmets.Demon_Horns:
                    return new Helmet( 0, 1 )
                    {
                        Health = 500,
                        Defence = 800,
                        Name = "Demon Horns",
                        Restrictions = PlayerType.Warrior,
                        Description = "The poor demon. He really liked these too.",
                        Sprite = Textures.GetHelmet( HelmetType.Demon_Horns ),
                        Cost = 1000
                    };
                case Helmets.Dunce_Cap:
                    return new Helmet( 2, 2 )
                    {
                        Defence = 30,
                        Damage = 100,
                        Name = "Dunce Cap",
                        Restrictions = PlayerType.Mage,
                        Description = "For when you feel like you could have played that last level a bit smarter.",
                        Sprite = Textures.GetHelmet( HelmetType.Dunce_Cap ),
                        Cost = 100
                    };
                case Helmets.Fake_Crown:
                    return new Helmet( 1, 3 )
                    {
                        Defence = 3,
                        Damage = 10,
                        Name = "Fake Crown",
                        Restrictions = PlayerType.Mage,
                        Description = "So you got it at a toy shop. It still works. Kinda.",
                        Sprite = Textures.GetHelmet( HelmetType.Fake_Crown ),
                        Cost = 10
                    };
                case Helmets.Feathered_Hat:
                    return new Helmet( 2, 0 )
                    {
                        Defence = 50,
                        Dexterity = 80,
                        Name = "Feathered Hat",
                        Restrictions = PlayerType.Rogue,
                        Description = "Stolen straight from Robin Hood's smug head.",
                        Sprite = Textures.GetHelmet( HelmetType.Feathered_Hat ),
                        Cost = 100
                    };
                case Helmets.Iron_Cap:
                    return new Helmet( 3, 0 )
                    {
                        Defence = 80,
                        Health = 50,
                        Name = "Iron Cap",
                        Restrictions = PlayerType.Warrior,
                        Description = "Some consider this better than a pot. Even though you can't cook with it.",
                        Sprite = Textures.GetHelmet( HelmetType.Iron_Cap ),
                        Cost = 100
                    };
                case Helmets.Wizards_Hat:
                    return new Helmet( 1, 2 )
                    {
                        Defence = 300,
                        Damage = 1000,
                        Name = "Wizard's Hat",
                        Restrictions = PlayerType.Mage,
                        Description = "The wizard on the hat is spelt Wizzard. One z's more powerful than a normal wizard.",
                        Sprite = Textures.GetHelmet( HelmetType.Wizards_Hat ),
                        Cost = 1000
                    };
                default:
                    throw new ArgumentException( "The helmet type " + type.ToString() + " does not have a switch case in the Helmet class." );
            }
        }
    }
}
