﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Game_Engine_Team.Actors;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game_Engine_Team.Equipment
{
    /// <summary>
    /// A Shirt equipment that provides defence bonuses to a character. Before this class is used
    /// the spritesheet for it needs to be loaded.
    /// 
    /// Author: Jonathan Gribble
    /// Sub-Author:
    /// 
    /// Created: Nov 15th
    /// Last Update: Nov 18th
    /// </summary>
    class Shirt : Equipment
    {
        /// <summary>
        /// The spritesheet representing Shirts.
        /// </summary>
        public static Texture2D spritesheet;

        /// <summary>
        /// Creates the Shirt.
        /// </summary>
        /// <param name="col">The x-location of the sprite on the spritesheet.</param>
        /// <param name="row">The y-location of the sprite on the spritesheet.</param>
        public Shirt( int col, int row ) : base( col, row, spritesheet ) { }

        /// <summary>
        /// Makes sure to unequip the previous item before equipping the new one.
        /// </summary>
        /// <param name="target"></param>
        public override void Equip( Player target )
        {
            if ( target.Class != Restrictions )
                return;
            if ( target.Equipment[ EquipmentSlots.Body ] != null )
                target.Equipment[ EquipmentSlots.Body ].Unequip( target );
            base.Equip( target );
        }

        /// <summary>
        /// Removes the equipment from the character.
        /// </summary>
        /// <param name="target"></param>
        public override void Unequip( Player target )
        {
            target.Equipment[ EquipmentSlots.Body ] = null;
            base.Unequip( target );
        }

        /// <summary>
        /// Creates a Shirt of the provided type.
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static Equipment CreateShirt( Shirts type )
        {
            switch ( type )
            {
                case Shirts.Assassin_Cloak:
                    return new Shirt( 6, 4 )
                    {
                        Dexterity = 750,
                        Defence = 550,
                        Name = "Assassin Cloak",
                        Restrictions = PlayerType.Rogue,
                        Description = "Though the cloak is supposed to be black, all the dried blood makes it appear brown.",
                        Sprite = Textures.GetShirt( ShirtType.Assassin_Cloak ),
                        Cost = 1000
                    };
                case Shirts.Demon_Breastplate:
                    return new Shirt( 0, 1 )
                    {
                        Defence = 9,
                        Health = 3,
                        Name = "Demon Breastplate",
                        Restrictions = PlayerType.Warrior,
                        Description = "Taken straight from the demon itself. It's still warm... Eww",
                        Sprite = Textures.GetShirt( ShirtType.Demon_Breastplate ),
                        Cost = 1000
                    };
                case Shirts.Elven_Cloak:
                    return new Shirt( 0, 4 )
                    {
                        Defence = 50,
                        Dexterity = 80,
                        Name = "Elven Cloak",
                        Restrictions = PlayerType.Rogue,
                        Description = "Stolen from so-called elves. At least, thats what you tell people.",
                        Sprite = Textures.GetShirt( ShirtType.Elven_Cloak ),
                        Cost = 100
                    };
                case Shirts.Gandalfs_Robes:
                    return new Shirt( 7, 4 )
                    {
                        Defence = 300,
                        Damage = 1000,
                        Name = "Gandalf's Robes",
                        Restrictions = PlayerType.Rogue,
                        Description = "Once belonging to Gandalf The Grey. Or White. Whatever he was calling himself.",
                        Sprite = Textures.GetShirt( ShirtType.Gandalfs_Robes ),
                        Cost = 1000
                    };
                case Shirts.Iron_Chestplate:
                    return new Shirt( 2, 6 )
                    {
                        Defence = 80,
                        Health = 50,
                        Name = "Iron Chestplate",
                        Restrictions = PlayerType.Warrior,
                        Description = "A chunk of solid iron in the rough shape of a chestplate.",
                        Sprite = Textures.GetShirt( ShirtType.Iron_Chestplate ),
                        Cost = 100
                    };
                case Shirts.Jean_Jacket:
                    return new Shirt( 3, 7 )
                    {
                        Health = 5,
                        Defence = 8,
                        Name = "Jean Jacket",
                        Restrictions = PlayerType.Warrior,
                        Description = "Left overs from the 90's. Still works well for absorbing Damage.",
                        Sprite = Textures.GetShirt( ShirtType.Jean_Jacket ),
                        Cost = 10
                    };
                case Shirts.Leather_Shirt:
                    return new Shirt( 0, 7 )
                    {
                        Dexterity = 8,
                        Defence = 5,
                        Name = "Leather Shirt",
                        Restrictions = PlayerType.Rogue,
                        Description = "Has a tag saying $9.99 at Kinks R' Us.",
                        Sprite = Textures.GetShirt( ShirtType.Leather_Shirt ),
                        Cost = 10
                    };
                case Shirts.Magic_Clothes:
                    return new Shirt( 2, 7 )
                    {
                        Defence = 30,
                        Damage = 100,
                        Name = "Magic Clothes",
                        Restrictions = PlayerType.Mage,
                        Description = "100% Guanranteed. Warning the magical qualities of these clothes are not 100% guaranteed.",
                        Sprite = Textures.GetShirt( ShirtType.Magic_Clothes ),
                        Cost = 100
                    };
                case Shirts.T_Shirt:
                    return new Shirt( 7, 7 )
                    {
                        Defence = 3,
                        Damage = 10,
                        Name = "T-Shirt",
                        Restrictions = PlayerType.Mage,
                        Description = "This T-Shirt looks a lot like a dress. Oh well, it still works.",
                        Sprite = Textures.GetShirt( ShirtType.T_Shirt ),
                        Cost = 10
                    };
                default:
                    throw new ArgumentException( "The Shirt type " + type.ToString() + " does not have a switch case in the Shirt class." );
            }
        }
    }
}
