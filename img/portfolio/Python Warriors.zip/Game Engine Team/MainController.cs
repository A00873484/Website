﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Game_Engine_Team.Texture;
using Game_Engine_Team.Actors;
using Controls;
using Game_Engine_Team.Sounds;

namespace Game_Engine_Team
{
    /// <summary>
    /// Controls which screen of the gameState is currently being displayed, and handles basic communication between
    /// the various screens and also handles media playing of songs.
    /// </summary>
    public class MainController : Microsoft.Xna.Framework.Game
    {
        private GraphicsDeviceManager graphics;

        public static int WIDTH;
        public static int HEIGHT;
        public static bool FULLSCREEN;

        /// <summary>
        /// The current keyboard state.
        /// </summary>
        public KeyboardState Keyboard { get; private set; }
        /// <summary>
        /// The current mouse state.
        /// </summary>
        public MouseState Mouse { get; private set; }
        /// <summary>
        /// The current gamepad state.
        /// </summary>
        public GamePadState GamePad { get; private set; }

        /// <summary>
        /// The previous keyboard state.
        /// </summary>
        public KeyboardState PastKeyboard { get; private set; }
        /// <summary>
        /// The previous mouse state.
        /// </summary>
        public MouseState PastMouse { get; private set; }
        /// <summary>
        /// The previous gamepad state.
        /// </summary>
        public GamePadState PastGamePad { get; private set; }
        

        private Stack<Screen> screenStack = new Stack<Screen>();

        private Screen CurrentScreen
        {
            get {
                return screenStack.Peek();
            }
        }

        protected void PushScreen( Screen newScreen )
        {
            screenStack.Push( newScreen );
            PlayMusic(newScreen.Music);
        }

        protected Screen PopScreen()
        {
            Screen screen = screenStack.Pop();
            MediaPlayer.Stop();
            screen.Dispose();
            PlayMusic(screenStack.Peek().Music);
            return screen;
        }

        private void PlayMusic(Song song)
        {
            if (song != null)
                MediaPlayer.Play(song);
        }

        /// <summary>
        /// Adds a screen to the stack and begins redirecting all Update and 
        /// Draw calls to it.
        /// </summary>
        /// <param name="nextScreen"></param>
        public void Launch( Screen nextScreen )
        {
            PushScreen( nextScreen );
        }

        /// <summary>
        /// Removes the current screen from the stack and stops directing any 
        /// Update or Draw calls to it.
        /// </summary>
        public void Back()
        {
            PopScreen();
        }


        public MainController( string authToken )
        {
            this.Window.Title = "Python Warriors";
            graphics = new GraphicsDeviceManager( this );
            Screen.Width = graphics.PreferredBackBufferWidth = ( Dungeon.WIDTH + 2 ) * Tile.WIDTH;
            Screen.Height = graphics.PreferredBackBufferHeight = Dungeon.HEIGHT * Tile.HEIGHT;
            IsMouseVisible = true;
            MediaPlayer.IsRepeating = true;

            Content.RootDirectory = "Content";

            User.Instance.AuthToken = authToken;
        }

        /// <summary>
        /// Allows the gameState to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per gameState and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            Textures.Inititialize( Content );
            SoundDaemon.Initialize(Content);
            Projectiles.Initialize();
            Enemy.Database.Initialize();

            PushScreen( new MainMenu( this ) );
        }


        /// <summary>
        /// UnloadContent will be called once per gameState and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }


        /// <summary>
        /// Allows the gameState to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update( GameTime gameTime )
        {
            if ( screenStack.Count < 1 )
                this.Exit();

            Keyboard = Microsoft.Xna.Framework.Input.Keyboard.GetState();
            Mouse = Microsoft.Xna.Framework.Input.Mouse.GetState();
            GamePad = Microsoft.Xna.Framework.Input.GamePad.GetState( PlayerIndex.One );
                        

            CurrentScreen.Update( gameTime );


            PastKeyboard = Keyboard;
            PastMouse = Mouse;
            PastGamePad = GamePad;
        }


        /// <summary>
        /// This is called when the gameState should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw( GameTime gameTime )
        {
            using ( Canvas canvas = new Canvas( GraphicsDevice ) )
            {
                CurrentScreen.Draw( canvas );
            }
        }
    }
}
