﻿using Controls;
using Game_Engine_Team.Actors;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Game_Engine_Team
{
    public class EditEnvironment : Screen
    {
        private WallTexture wallGraphicA;
        private WallTexture wallGraphicB;

        private FloorTexture floorGraphicA;
        private FloorTexture floorGraphicB;

        private FloorTexture bridgeGraphicA;

        private PitTexture pitGraphicA;
        private PitTexture pitGraphicB;
        private PitTexture pitGraphicC;
        private PitTexture pitGraphicD;

        private Dungeon dungeon;

        private EditToolbox toolbox;


        Tile[] BuilderTiles;

        public enum PaintingMode
        {
            None, Tiles, Enemies, Spawn, Waypoint
        }

        public override void Dispose()
        {
            base.Dispose();
            toolbox.Close();
        }

        private bool isPainting = false;
        private EnemyType selectedEnemy;
        private Tile  selectedTile;

        public PaintingMode PaintMode { get; private set; }

        private void PaintAt( int x, int y )
        {
            if ( !dungeon.ContainsCoord( new Point( x, y ) ) )
                return;

            switch ( PaintMode )
            {
                case PaintingMode.None:
                    break;

                case PaintingMode.Tiles:
                    dungeon.PlaceTile( x, y, selectedTile );
                    break;

                case PaintingMode.Enemies:
                    if ( dungeon.PlaceEnemy( x, y, selectedEnemy ) )
                        PaintMode = PaintingMode.None;
                    break;

                case PaintingMode.Spawn:
                    if ( dungeon.SetPlayerSpawn( x, y ) )
                        PaintMode = PaintingMode.None;
                    break;

                case PaintingMode.Waypoint:
                    dungeon.AddWaypoint( x, y );
                    break;
            }
        }

        private void RemoveEnemyAt( int x, int y )
        {
            dungeon.RemoveEnemyAt( x, y );
        }

        public Sprite SelectedIcon
        {
            get {
                switch ( PaintMode )
                {
                    default:
                    case PaintingMode.None:
                        return null;

                    case PaintingMode.Tiles:
                        return selectedTile.Texture.Icon;

                    case PaintingMode.Enemies:
                        return Textures.Get( selectedEnemy ).Icon;

                    case PaintingMode.Spawn:
                    case PaintingMode.Waypoint:
                        return Textures.Get( EffectType.Waypoint ).Icon;
                }
            }
        }

        public void UnsetSelected()
        {
            PaintMode = PaintingMode.None;
        }

        public void SetSelected( Tile tile )
        {
            selectedTile = tile;
            PaintMode = PaintingMode.Tiles;
        }

        public void SetSelected( EnemyType type )
        {
            selectedEnemy = type;
            PaintMode = PaintingMode.Enemies;
        }

        public void SetSpawnMode()
        {
            PaintMode = PaintingMode.Spawn;
        }

        public void SetWaypointMode()
        {
            PaintMode = PaintingMode.Waypoint;
        }


        public EditEnvironment( MainController game, Dungeon _dungeon )
            : base( game )
        {
            this.dungeon = Dungeon.Load( "Dungeon.bin" ) ?? _dungeon;
            this.dungeon.EditMode = true;

            LoadContent();

            //Dummy data need to be replaced with Tiles the User has access to
            BuilderTiles = new Tile[] {
                new WallTile( Dungeon.WIDTH, 0, wallGraphicA ),
                new WallTile( Dungeon.WIDTH + 1, 0, wallGraphicB ),
                new FloorTile( Dungeon.WIDTH, 1, floorGraphicA ),
                new FloorTile( Dungeon.WIDTH + 1, 1, floorGraphicB ),
                new PitTile( Dungeon.WIDTH, 2, pitGraphicA ),
                new PitTile( Dungeon.WIDTH + 1, 2, pitGraphicB ),
                new BridgeTile( Dungeon.WIDTH, 3, bridgeGraphicA ),
                new BridgeTile( Dungeon.WIDTH + 1, 3, floorGraphicA ),
                new PitTile( Dungeon.WIDTH, 4, pitGraphicC ),
                new PitTile( Dungeon.WIDTH + 1, 4, pitGraphicD ),
            };

            toolbox = new EditToolbox();

            toolbox.AddTile( "Light Wall", BuilderTiles[ 0 ] );
            toolbox.AddTile( "Dark Wall", BuilderTiles[ 1 ] );
            toolbox.AddTile( "Light Floor", BuilderTiles[ 2 ] );
            toolbox.AddTile( "Dark Floor", BuilderTiles[ 3 ] );
            toolbox.AddTile( "Empty Pit", BuilderTiles[ 4 ] );
            toolbox.AddTile( "Lava Pit", BuilderTiles[ 5 ] );
            toolbox.AddTile( "Wood Bridge", BuilderTiles[ 6 ] );
            toolbox.AddTile( "Stone Bridge", BuilderTiles[ 7 ] );
            toolbox.AddTile( "Pool", BuilderTiles[ 8 ] );
            toolbox.AddTile( "Water Pit", BuilderTiles[ 9 ] );

            foreach ( var enemyType in EnumUtil.GetValues<EnemyType>() )
                toolbox.AddActor( enemyType );

            toolbox.TileSelected += SetSelected;
            toolbox.EnemySelected += SetSelected;
            toolbox.SpawnSelected += SetSpawnMode;
            toolbox.WaypointSelected += SetWaypointMode;

            toolbox.LinkDungeon( this.dungeon );

            toolbox.Show();
        }

        /// <summary>
        /// LoadContent will be called once per gameState and is the place to load
        /// all of your content.
        /// </summary>
        protected void LoadContent()
        {
            wallGraphicA = Textures.Get( WallType.Stone1 );
            wallGraphicB = Textures.Get( WallType.Stone3 );

            floorGraphicA = Textures.Get( FloorType.Stone0 );
            floorGraphicB = Textures.Get( FloorType.Stone2 );

            bridgeGraphicA = Textures.Get( FloorType.Wood1 );

            pitGraphicA = Textures.Get( PitType.Empty0 );
            pitGraphicB = Textures.Get( PitType.RoughLava );
            pitGraphicC = Textures.Get( PitType.Water0 );
            pitGraphicD = Textures.Get( PitType.RoughWater );
        }

        private void UpdateKeyboard( GameTime gameTime )
        {
            if ( Game.Keyboard != Game.PastKeyboard )
            {
                if ( Game.Keyboard.IsKeyDown( Keys.Space ) )
                {
                    dungeon.Save( "Dungeon.bin" );
                    Dungeon dunge = Dungeon.Load( "Dungeon.bin" );

                    Player player = new Warrior( dunge );

                    Game.Launch( new PlayEnvironment( Game, dunge, player ) );
                }
            }
        }

        private void UpdateMouse( GameTime gameTime )
        {
            if ( Game.Mouse.RightButton == ButtonState.Pressed )
            {
                if ( PaintMode != PaintingMode.None )
                {
                    UnsetSelected();
                }
                else
                {
                    int x = Game.Mouse.X / Tile.WIDTH;
                    int y = Game.Mouse.Y / Tile.HEIGHT;

                    RemoveEnemyAt( x, y );
                }
            }

            if ( Game.Mouse.LeftButton != Game.PastMouse.LeftButton )
            {
                //code run on a left mouse click
                if ( Game.Mouse.LeftButton == ButtonState.Pressed )
                {
                    Point mousePos = new Point( Game.Mouse.X, Game.Mouse.Y );
                    //check through the chooseable tiles to see if the mouse is on one of them
                    foreach ( Tile tile in BuilderTiles )
                    {
                        if ( tile.ContainsPixel( mousePos ) )
                        {
                            SetSelected( tile );
                            break;
                        }
                    }
                    //if the user is placing a tile rather than selecting one
                    if ( PaintMode != PaintingMode.None )
                    {
                        isPainting = true;
                    }
                }
            }

            if ( isPainting )
            {
                if ( Game.Mouse.LeftButton == ButtonState.Pressed )
                {
                    int x = Game.Mouse.X / Tile.WIDTH;
                    int y = Game.Mouse.Y / Tile.HEIGHT;

                    PaintAt( x, y );
                }
                else
                {
                    isPainting = false;
                }
            }
        }


        /// <summary>
        /// Allows the gameState to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update( GameTime gameTime )
        {
            base.Update( gameTime );

            if ( !Game.IsActive )
                return;

            UpdateKeyboard( gameTime );
            UpdateMouse( gameTime );
        }
        

        /// <summary>
        /// This is called when the gameState should draw itself.
        /// </summary>
        public override void Draw( Canvas canvas )
        {
            //draw the placed tiles
            dungeon.Draw( canvas );

            //draw the chooseable tiles
            foreach ( Tile bt in BuilderTiles )
                bt.Draw( canvas );

            //draw the current tile the user has selected on their mouse (if applicable)
            if ( !isPainting && PaintMode != PaintingMode.None )
            {
                int x = Game.Mouse.X / Tile.WIDTH;
                int y = Game.Mouse.Y / Tile.HEIGHT;

                if ( dungeon.ContainsCoord( new Point( x, y ) ) )
                {
                    Rectangle rect = new Rectangle( x * Tile.WIDTH, y * Tile.HEIGHT,
                                                    Tile.WIDTH, Tile.HEIGHT );

                    canvas.DrawRect( rect, new Color( 0, 0, 0, 70 ) );
                }

                Point iconPos = new Point( Game.Mouse.X - (Tile.WIDTH / 2),
                                           Game.Mouse.Y - (Tile.HEIGHT / 2) );

                canvas.Finish += c => c.Draw( SelectedIcon, iconPos, true );
            }

        }
    }
}
