﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Controls;

namespace Game_Engine_Team
{
    class CharacterSelect : Screen
    {
        /// <summary>
        /// The button controls that exist in the screen.
        /// </summary>
        private LinkedList<Button> buttons;

        /// <summary>
        /// The bounds of the popup character select screen
        /// </summary>
        Rectangle bounds;

        // Dictionary<string, int> characters

        /// <summary>
        /// Status of the screen
        /// </summary>
        public bool display { get; set; }

        /// <summary>
        /// Content manager passed in from MainMenu
        /// </summary>
        public ContentManager Content { get; private set; }

        /// <summary>
        /// The middle of the screen.
        /// </summary>
        private int middle;

        /// <summary>
        /// Creates a Character select screen
        /// </summary>
        /// <param name="content"></param>
        public CharacterSelect( MainController game )
            : base( game )
        {
            Content = Game.Content;

            display = true;
            int width = Screen.Width / 2;
            int height = (int)(Screen.Height * .8);

            int x = (Screen.Width - width) / 2;
            int y = (Screen.Height - height) / 2;

            bounds = new Rectangle(x, y, width, height);

            buttons = new LinkedList<Button>();

            SpriteFont monospace = Content.Load<SpriteFont>("Fonts/MonoSpace");
            buttons.AddLast(new Button(monospace, "Submit", 0, 0, 100));
            //buttons.Last.Value.On_Button_Click += new Button.ButtonClick(SubmitClick);
            buttons.AddLast(new Button(monospace, "Create", 0, 0, 100));
            //buttons.Last.Value.On_Button_Click += new Button.ButtonClick(CreateClick);
            buttons.AddLast(new Button(monospace, "Cancel", 0, 0, 100));
            buttons.Last.Value.On_Button_Click += new Button.ButtonClick(CancelClick);

            //todo populate list with characters
        }

        /// <summary>
        /// Draws the screen
        /// </summary>
        /// <param name="canvas"></param>
        public override void Draw(Canvas canvas)
        {
            //draw buttons
            //todo draw rectangle around selected character
            //todo foreach character in list, draw character name and xp
            PrimitiveShapes.FillRectangle(canvas, bounds, Color.Black);
            PrimitiveShapes.DrawRectangle(canvas, bounds, PrimitiveShapes.Darken(Color.Chocolate), 3.0f);
            //canvas.End();
            foreach (Button btn in buttons)
                btn.Draw(canvas);
            //canvas.Begin();
        }

        /// <summary>
        /// Fires when the submit button is clicked
        /// </summary>
        public void SubmitClick()
        {
            //todo set active character to selected character
        }

        /// <summary>
        /// Fires when the create button is clicked
        /// </summary>
        public void CreateClick()
        {
            //todo send to create character screen
        }

        /// <summary>
        /// Fires when the cancel button is clicked
        /// </summary>
        public void CancelClick()
        {
            display = false;
        }

        /// <summary>
        /// Updates the screen
        /// </summary>
        /// <param name="gameTime"></param>
        public override void Update(Microsoft.Xna.Framework.GameTime gameTime)
        {
            //update buttons
            if (middle != Screen.Width / 2)
                middle = Screen.Width / 2;
            int vertical = Screen.Height / 2;
            int verticalPadding = 5;

            int width = buttons.First.Value.Location.Width;
            int height = buttons.First.Value.Location.Height;

            int startX = middle - (width + 56);
            int startY = vertical + (7 * height - 6 * verticalPadding);

            foreach (Button btn in buttons)
            {
                btn.Location = new Rectangle(startX, startY, width, height);
                btn.Text = btn.Text;
                startX += width + verticalPadding;
            }
            foreach (Button btn in buttons)
                btn.Update();

            //todo determine if character clicked on. if so then highlight
        }
    }
}
