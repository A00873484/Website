﻿using Controls;
using Microsoft.Xna.Framework;

// Andrew Meckling
namespace Game_Engine_Team
{
    /// <summary>
    /// Interface for objects which have a physical location in the gameState world 
    /// and a visual representation or that may change state over time.
    /// </summary>
    public interface IEntity
    {
        /// <summary>
        /// Gets the x-coordinate of the Entity.
        /// </summary>
        int X { get; }

        /// <summary>
        /// Gets the y-coordinate of the Entity.
        /// </summary>
        int Y { get; }

        /// <summary>
        /// Gets the pos of the Entity.
        /// </summary>
        Point Position { get; }

        /// <summary>
        /// Gets a value indicating whether the Entity should be removed from 
        /// the gameState world.
        /// </summary>
        bool Expired { get; }

        /// <summary>
        /// Runs update logic for the Entity.
        /// </summary>
        /// <param name="gameTime">Snapshot of the GameTime at the time the 
        /// method is called.</param>
        void Update( GameTime gameTime );

        /// <summary>
        /// Runs drawing logic for the Entity.
        /// </summary>
        /// <param name="canvas">Canvas object on which to draw the Entity.</param>
        void Draw( Canvas canvas );
    }
}
