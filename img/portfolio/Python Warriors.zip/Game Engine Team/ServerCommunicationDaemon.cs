﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using System.Diagnostics;

namespace Game_Engine_Team 
{
    /// <summary>
    /// A singleton daemon object used to assist in the aquisition and storing data into the database.
    /// Called using ServerCommunicationDaemon.Instance
    /// 
    /// Creators: Jacob Lim, Morgan Wynne, Carl Kuang
    /// </summary>
    public class ServerCommunicationDaemon 
    {

        /// <summary>
        /// The singleton instance getter for the daemon
        /// </summary>
        public static ServerCommunicationDaemon Instance
        {
            get;
            private set;
        }

        static ServerCommunicationDaemon()
        {
            Instance = new ServerCommunicationDaemon();
        }

        private ServerCommunicationDaemon()
        {
        }

        /// <summary>
        /// Return a User consisting of the user data, using username and password.
        /// This is a helper function used for Login.
        /// 
        /// Created by: Jacob Lim
        /// </summary>
        /// <param name="username">Username of user.</param>
        /// <param name="password">Password of user.</param>
        /// <returns></returns>
        /// <author>Jacob Lim</author>
        public User GetUserData( string username, string password )
        {
            string jsonUserResult;

            // The server url that we'll be retrieving character data from
            string getUserEndpoint = "http://techproprojects.bcit.ca:6363/loginservice.svc/player/";

            // Adds account information to the user endpoint url
            getUserEndpoint = getUserEndpoint + username + "/" + password;

            using (var server = new WebClient())
            {
                // Downloads the resulting json into jsonUserResult
                jsonUserResult = server.DownloadString(getUserEndpoint); //Jacob: alternative to using streamReader.ReadToEnd() I guess?
            }
            dynamic userData = JsonConvert.DeserializeObject<Object>(jsonUserResult);

            // Return the new User object
            return new User()
            {
                Balance = userData.Balance
            };
        }

        /// <summary>
        /// Login, using username and password.
        /// 
        /// Created by: Jacob Lim
        /// Edited by: Morgan Wynne
        /// </summary>
        /// <returns>User containing all user information</returns>
        /// <exception cref="WebException">if the login data is incorrect</exception>
        public User Login( string username, string password )
        {
            // The json strings returned from the server
            string jsonAuthResult;

            // The server url that we'll be acquiring an authentication key from
            string getAuthEndpoint = "http://techproprojects.bcit.ca:6363/LoginService.svc/login";

            // The exact json string that will be sent to the server for the authentication key
            string json = "{\"username\":\"" + username + "\"," +
                          "\"password\":\"" + password + "\"}";

            // Opens and writes to the http request to the server
            HttpWebRequest httpWebRequest = WebRequest.CreateHttp( getAuthEndpoint );
            httpWebRequest.ContentType = "text/json";
            httpWebRequest.Method = "POST";
            using( var streamWriter = new StreamWriter( httpWebRequest.GetRequestStream() ) ) {
                streamWriter.Write( json );
            }

            // Reads back the response
            HttpWebResponse httpResponse = ( httpWebRequest.GetResponse() as HttpWebResponse ); //throws the WebException
            using ( var streamReader = new StreamReader( httpResponse.GetResponseStream() ) )
            {
                jsonAuthResult = streamReader.ReadToEnd(); //contains AuthToken
            }

            // Deserializes the Json string for the Auth result
            dynamic authData = JsonConvert.DeserializeObject<Object>( jsonAuthResult );

            User user = GetUserData(username, password);
            user.AuthToken = authData.LoginResult;

            // Returns a new user using data from the Json objects
            return user;
        }
        
        /// <summary>
        /// Registers a user with the gameState assuming everything is valid. An account is considered valid if the following is
        /// true: All the fields are completed, a unique username, a unique email address and the passwords match.
        /// 
        /// Created by: Server/Communication team, Morgan Wynne, Jacob Lim
        /// </summary>
        /// <param name="username">Username of user</param>
        /// <param name="password">Password of user</param>
        /// <param name="email">E-mail of user</param>
        /// <returns>Success or failure boolean of registration</returns>
        public Boolean Register(string username, string password, string email)
        {
            // The json string returned from the server
            string jsonRsgrResult;

            // The server url that we'll be passing the new registration data to
            string registerEndpoint = "http://techproprojects.bcit.ca:6363/RegisterService.svc/player";

            string json = "{\"username\":\"" + username + "\"," +
                          "\"password\":\"" + password + "\"," +
                          "\"email\":\"" + email + "\"}";

            // Opens and writes the http request to the server
            var httpWebRequest = WebRequest.CreateHttp( registerEndpoint );
            httpWebRequest.ContentType = "text/json";
            httpWebRequest.Method = "POST";
            using ( var streamWriter = new StreamWriter( httpWebRequest.GetRequestStream() ) )
            {
                streamWriter.Write( json );
            }

            // Reads back the response
            var httpResponse = (httpWebRequest.GetResponse() as HttpWebResponse);
            using ( var streamReader = new StreamReader( httpResponse.GetResponseStream() ) )
            {
                jsonRsgrResult = streamReader.ReadToEnd();
            }

            dynamic rsgrData = JsonConvert.DeserializeObject<Object>( jsonRsgrResult );

            // Returns if the registration was successful
            return Boolean.Parse( ((String) rsgrData.RegisterNewUserResult).ToLower() );
        }

        /// <summary>
        /// Get all available character names.
        /// 
        /// Created by: Jacob Lim
        /// Edited by: Morgan Wynne
        /// </summary>
        public void ListCharacters()
        {
            // This is an example of writing data to the database
            string endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/getallavailablecharacternames";

            // Creates the initial HTTP request object to the server
            HttpWebRequest httpWebRequest = WebRequest.CreateHttp( endpoint );

            httpWebRequest.ContentType = "text/json";
            httpWebRequest.Method = "GET";

            // Reads back and prints the response
            var httpResponse = (HttpWebResponse) httpWebRequest.GetResponse();

            // Opens a stream to the response and parses the data
            using ( var streamReader = new StreamReader( httpResponse.GetResponseStream() ) )
            {
                var result = streamReader.ReadToEnd();
                MessageBox.Show( result );
            }
        }

        /// <summary>
        /// Get a character of the currently logged in user by its character name.
        /// </summary>
        /// <param name="CharName">Character name</param>
        /// <param name="AuthToken">User's login token</param>
        /// <returns>the character</returns>
        /// <author>Carl Kuang</author>
        public Character GetCharacter( string CharName, string AuthToken )
        {
            string endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/getcharacter/" + CharName;
            JObject c = JObject.Parse(EndPointRequest.Get(endpoint, AuthToken));
            Character character = new Character(c["CharName"].ToString(), c["CharacterObj"].ToString(), c["Stage"].ToString(), Int32.Parse(c["StageExp"].ToString()));
            // need to store Id and Updated as well
            return character;
        }

        /// <summary>
        /// Get the item and its quantity of the currently logged in user by its id
        /// 
        /// Created by: Carl Kuang
        /// </summary>
        /// <param name="itemID">Item's id</param>
        /// <param name="AuthToken">User's login token</param>
        /// <returns>A KeyValuePair of the item's name and value</returns>
        /// <author>Carl Kuang</author>
        public KeyValuePair<string, int> GetItem( string itemID, string AuthToken )
        {
            string endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/getitem/" + itemID;
            JObject itemJObject = JObject.Parse(EndPointRequest.Get(endpoint, AuthToken));
            KeyValuePair<string, int> item = new KeyValuePair<string, int>(itemJObject["ItemID"].ToString(), int.Parse(itemJObject["Quantity"].ToString()));
            return item;
        }

        /// <summary>
        /// Get all items in the currently logged in user's inventory.
        /// Jacob: Note that this method currently does not work.
        /// 
        /// Created by: Carl Kuang
        /// </summary>
        /// <param name="AuthToken">User's login token</param>
        /// <returns>Array of string of the item list</returns>
        /// <author>Carl Kuang</author>
        public string[] GetAllItemIDByUsername( string AuthToken )
        {
            string endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/getallitemsbyuserid";
            JArray itemArray = JArray.Parse(EndPointRequest.Get(endpoint, AuthToken));

            return itemArray.Select(it => (string)it).ToArray();
            //JObject itemJObject = JObject.Parse(EndPointRequest.Get(endpoint, AuthToken));
            //KeyValuePair<string, int> item = new KeyValuePair<string, int>(itemJObject["ItemID"].ToString(), int.Parse(itemJObject["Quantity"].ToString()));

        }
            
        /// <summary>
        /// Save a list of items to the currently logged in user.
        /// </summary>
        /// <param name="items">the list of items to be saved</param>
        /// <param name="AuthToken">user's login token</param>
        /// <returns>true if saved successfully</returns>
        /// <author>Carl Kuang</author>
        public string SaveAllItems( Dictionary<string, int> items, string AuthToken )
            {
            string endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/saveallitemidbyusername";
            List<string> itemList = new List<string>();
            foreach (KeyValuePair<string, int> item in items)
            {
                itemList.Add("{\"Key\": \"" + item.Key + "\", \"Value\": " + item.Value + "}");
            }
            string itemListString = string.Join(", ", itemList.ToArray<string>());
            string json = "{\"itemIdList\": [" + itemListString + "]}";
            Debug.WriteLine(json);
            //dynamic saveResult = JsonConvert.DeserializeObject<Object>(EndPointRequest.Post(endpoint, json, token));
            //return saveResult;
            return EndPointRequest.Post(endpoint, json, AuthToken);
        }

        /// <summary>
        /// Return stage as the decimal number of binary string.
        /// 
        /// Created by: Jacob Lim
        /// </summary>
        /// <param name="charName">Character name</param>
        /// <param name="AuthToken">User's authentication token</param>
        /// <returns>String of Stage data</returns>
        /// <author>Jacob Lim</author>
        /// 
        public string GetStage( string charName, string AuthToken ) //does this require an AuthToken?
        {
            string endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/getstagebycharname/"+charName;
            string jsonStage = EndPointRequest.Get(endpoint, AuthToken);
            dynamic StageResult = JsonConvert.DeserializeObject<Object>(jsonStage);
            return StageResult.GetStageByCharNameResult;
        }

        /// <summary>
        /// Save the balance to currently logged in user.
        /// 
        /// Created by: Carl Kuang, Jacob Lim
        /// </summary>
        /// <param name="balance">balance want to save</param>
        /// <param name="token">user login token</param>
        /// <returns>true if save operation succeed</returns>
        /// <author>Carl Kuang</author>
        public bool SaveBalance( int balance, string AuthToken ) //Requires a user ID
            {
            string endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/savebalancebyuserid";
            string json = "{\"balance\":" + balance + "}";
            dynamic saveResult = JsonConvert.DeserializeObject<Object>(EndPointRequest.Post(endpoint, json, AuthToken));
            return saveResult.SaveBalanceByUserIdResult;
        }

        /// <summary>
        /// Search characters by their character names.
        /// 
        /// Created by: Carl Kuang
        /// </summary>
        /// <param name="character">Character name</param>
        /// <returns>List of character names</returns>
        /// <author>Carl Kuang</author>
        public List<string> SearchCharacter(string character)
        {
            return SearchCharacter(null, character);
        }

        /// <summary>
        /// Search characters by their usernames and/or character names.
        /// </summary>
        /// <param name="user">Username</param>
        /// <param name="character">Character name</param>
        /// <returns>List of character names</returns>
        /// <author>Carl Kuang</author>
        public List<string> SearchCharacter(string user, string character)
        {
            string endpoint = "";
            bool isUserNull = user == null || user.Equals("");
            bool isCharNull = character == null || character.Equals("");
            if (isUserNull && isCharNull)
            {
                endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/searchcharacter";
            }
            else if (isUserNull)
            {
                endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/searchcharacterbycharname/" + character;
            }
            else if (isCharNull)
            {
                endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/searchcharacterbyusername/" + user;
            }
            else
            {
                endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/searchcharacterbyusernamecharname/" + user + "/" + character;
            }
            JObject listObject = JObject.Parse(EndPointRequest.Get(endpoint));
            JArray listArray = (JArray)listObject.First.First;
            List<string> characterNames = new List<string>();
            foreach (JObject charset in listArray)
            {
                characterNames.Add(charset["CharName"] + "@" + charset["UserName"] + ": " + charset["Exp"]);
            }
            return characterNames;
        }
        
        /// <summary>
        /// Create a new Character for the user.
        /// This returns a boolean reflecting whether it is successful.
        /// Note: throwing a WebException can be considered as well - as that has been done for error handling.
        /// It could already be throwing it, actually - so do a try, catch block for this.
        /// 
        /// Created by: Jacob Lim
        /// </summary>
        /// <param name="charName">Character name</param>
        /// <param name="character">Character object</param>
        /// <param name="stage">Stage object</param>
        /// <param name="stageExp">Stage EXP (experience)</param>
        /// <param name="AuthToken">User's Authentication token</param>
        /// <returns>true or false reflecting whether creation of the Character was successful</returns>
        /// <author>Jacob Lim</author>
        public bool CreateANewCharacter(string charName, string character, string stage, string stageExp, string AuthToken)
        {
            string endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/createnewcharacter";
            string jsonResult = EndPointRequest.Post(endpoint,
            "{\"charName\" : \"" + charName + "\"," +
            "\"character\" : \"" + character + "\"," +
            "\"stage\" : \"" + stage + "\"," +
            "\"stageExp\" : " + stageExp + "}", AuthToken);

            dynamic saveResult = JsonConvert.DeserializeObject<Object>(jsonResult);
            return saveResult.CreateNewCharacterResult;
        }

        /// <summary>
        /// This obtains the characters belonging to the current user,
        /// as a List of Characters.
        /// 
        /// Created by: Jacob Lim
        /// </summary>
        /// <param name="AuthToken">User's authentication token</param>
        /// <returns>a List of the Characters made by the current user</returns>
        /// <author>Jacob Lim</author>
        public List<Character> GetAllCharactersOfUser( string AuthToken )
            {
            string endpoint = "http://techproprojects.bcit.ca:6363/GameAPI.svc/gameapi/getallcharacter";
            string JsonUserChars = EndPointRequest.Get(endpoint, AuthToken);

            // Deserializes the Json string for the Auth result
            dynamic DUserChars = JsonConvert.DeserializeObject<Object>(JsonUserChars);
            JArray charResult = DUserChars.GetAllCharacterResult;
            List<Character> UserChars = new List<Character>();

            //insert Character object into result
            //The implementation of the Character object, and in turn this code, could be subject to change.
            for (int i = 0; i < charResult.Count; i++ )
            {
                dynamic Char = charResult[i];
                //get CharacterObj property in element 0 of the GetAllCharacterResult JArray
                Character c = new Character((string)Char.CharName, (string)Char.CharacterObj, (string)Char.Stage, Int32.Parse((string)Char.StageExp)); //The CharacterObj and Stage data are stored as strings.
                UserChars.Add(c);
        }

            // Returns the characters belonging to the current user
            return UserChars;
        }

        /**
         * 1. login (saymyname/saymyname), get auth token, put that token into header of get character request
         * 2. can use "Hero" or "Enemy" <or "Aloha" or such> as the character name
         */
    }
}
