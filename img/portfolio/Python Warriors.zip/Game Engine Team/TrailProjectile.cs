﻿using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Engine_Team
{
    public class TrailProjectile : Projectile
    {

        private int lifespan;

        public int HazardDamage { get; private set; }

        private Sprite hazardSprite;
        private Sprite hazardSpriteLast;

        public TrailProjectile( int x, int y, Direction dir,
                                 int range, int lifespan,
                                 int damage, int hazardDamage,
                                 Sprite sprite,
                                 Sprite hazardSprite = null,
                                 Sprite hazardSpriteLast = null )
            : base( x, y, dir, range, damage, sprite )
        {
            this.lifespan = lifespan;

            HazardDamage = hazardDamage;

            this.hazardSprite = hazardSprite ?? sprite;
            this.hazardSpriteLast = hazardSpriteLast ?? this.hazardSprite;

            this.PassThrough = true;
        }

        private Hazard hazard = null;

        protected override void Move()
        {
            base.Move();

            hazard = new Hazard( this.X, this.Y, lifespan, HazardDamage, hazardSprite.Spawn(), hazardSpriteLast.Spawn() );
        }

        public override bool DeliverEffect( Dungeon stage )
        {
            bool ret = base.DeliverEffect( stage );

            if ( hazard != null && !this.Expired )
            {
                stage.AddHazard( hazard );
                hazard = null;
            }

            return ret;
        }

    }

    public class TrailProjectileEmitter : ProjectileEmitter
    {
        public int Lifespan;
        public Sprite HazardSprite;
        public Sprite HazardSpriteLast;

        public int HazardDamage;

        public TrailProjectileEmitter( int range, int lifespan,
                                        int damage, int hazardDamage,
                                        Sprite sprite,
                                        Sprite hazardSprite = null,
                                        Sprite hazardSpriteLast = null )
            : base( range, damage, sprite )
        {
            Lifespan = lifespan;
            HazardDamage = hazardDamage;

            HazardSprite = hazardSprite;
            HazardSpriteLast = hazardSpriteLast;
        }

        public override object Clone()
        {
            var emitter = this.MemberwiseClone() as TrailProjectileEmitter;
            emitter.HazardSprite = HazardSprite.Spawn();
            emitter.HazardSpriteLast = HazardSpriteLast.Spawn();
            return emitter;
        }

        protected override Projectile Emit( int x, int y, Direction dir, int? range )
        {
            return new TrailProjectile( x, y, dir, range ?? Range,
                                         Lifespan, Damage, HazardDamage,
                                         Sprite, HazardSprite, HazardSpriteLast );
        }
    }
}
