﻿using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.CSharp.RuntimeBinder;
using Game_Engine_Team.Actors;
using System.Diagnostics;
using System.IO;

namespace Game_Engine_Team
{

    public delegate void SelectTile( Tile tile );
    public delegate void SelectEnemy( EnemyType type );
    public delegate void SelectWaypoint();

    public partial class EditToolbox : Form
    {

        public event SelectTile TileSelected;
        public event SelectEnemy EnemySelected;
        public event SelectWaypoint SpawnSelected;
        public event SelectWaypoint WaypointSelected;

        private ImageList imageList = new ImageList();
        
        // Very dangerous, just like that song.
        private Dictionary<string, object> placeables = new Dictionary<string, object>();

        private TreeNode tilesNode;
        private TreeNode floorsNode;
        private TreeNode wallsNode;
        private TreeNode pitsNode;

        private TreeNode actorsNode;

        public EditToolbox()
        {
            InitializeComponent();

            treeView1.ImageList = imageList;
            listView1.SmallImageList = imageList;

            tilesNode = treeView1.Nodes.Find( "Tiles", false )[ 0 ];
            actorsNode = treeView1.Nodes.Find( "Enemies", false )[ 0 ];

            floorsNode = tilesNode.Nodes.Find( "Floors", false )[ 0 ];
            wallsNode = tilesNode.Nodes.Find( "Walls", false )[ 0 ];
            pitsNode = tilesNode.Nodes.Find("Pits", false)[0];
        }


        public void AddTile( string key, Tile placeable )
        {
            placeables[ key ] = placeable;
            imageList.Images.Add( key, placeable.Texture.Icon.ToBitmap() );

            TreeNode node = tilesNode;

            if ( placeable is FloorTile )
                node = floorsNode;

            else if ( placeable is WallTile )
                node = wallsNode;

            else if ( placeable is PitTile )
                node = pitsNode;

            node.Nodes.Add( key, key, key, key );
        }

        public void AddActor( EnemyType enemy )
        {
            string key = enemy.ToString();

            placeables[ key ] = enemy;
            imageList.Images.Add( key, Textures.Get( enemy ).Icon.ToBitmap() );
            imageList.Images.Add( key + "_sel", Textures.Get( enemy ).IconAlt.ToBitmap() );

            actorsNode.Nodes.Add( key, key, key, key + "_sel" );
        }

        private Dungeon dungeon;

        public void LinkDungeon( Dungeon dungeon )
        {
            this.dungeon = dungeon;

            dungeon.EnemyAdded += PlaceActor;
            dungeon.EnemyRemoved += UnplaceActor;

            foreach ( var pair in dungeon.Roster )
                PlaceActor( pair.Key, pair.Value );
        }

        public void PlaceActor( string name, Enemy enemy )
        {
            listView1.Items.Add( name, name, enemy.ToString() );
        }

        public void UnplaceActor( string name, Enemy enemy )
        {
            listView1.Items.RemoveByKey( name );
        }

        private void listView1_AfterLabelEdit( object sender, LabelEditEventArgs e )
        {
            var item = listView1.Items[ e.Item ];

            string oldName = item.Name;
            e.CancelEdit = !dungeon.RenameEnemy( oldName, e.Label );

            if ( !e.CancelEdit )
                item.Name = e.Label;
        }

        private void treeView1_AfterSelect( object sender, TreeViewEventArgs e )
        {
            if ( placeables.ContainsKey( e.Node.Name ) )
            {
                object selected = placeables[ e.Node.Name ];

                if ( selected is Tile && TileSelected != null )
                    TileSelected( (Tile) selected );

                else if ( selected is EnemyType && EnemySelected != null )
                    EnemySelected( (EnemyType) selected );
            }
            else if ( e.Node.Name == "Spawn" )
            {
                if ( SpawnSelected != null )
                    SpawnSelected();
            }
            else if ( e.Node.Name == "Waypoint" )
            {
                if ( WaypointSelected != null )
                    WaypointSelected();
            }
        }

        private void button1_Click( object sender, EventArgs e )
        {
            File.AppendText( "python.py" );
            Process.Start( "python.py" );
            File.AppendText( "python_setup.py" );
            Process.Start( "python_setup.py" );
        }

    }

    public static class SpriteExtentions
    {

        public static Bitmap ToBitmap( this Sprite sprite )
        {
            Texture2D texture = (Texture2D) sprite;

            Microsoft.Xna.Framework.Rectangle rect = new Microsoft.Xna.Framework.Rectangle(
                sprite.X * Sprite.WIDTH, sprite.Y * Sprite.HEIGHT, Sprite.WIDTH, Sprite.HEIGHT );

            Microsoft.Xna.Framework.Color[] data = new Microsoft.Xna.Framework.Color[ Sprite.WIDTH * Sprite.HEIGHT ];


            texture.GetData( 0, rect, data, 0, data.Length );

            Texture2D tex = new Texture2D( texture.GraphicsDevice, Sprite.WIDTH, Sprite.HEIGHT );

            tex.SetData( data );


            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            tex.SaveAsPng( ms, Sprite.WIDTH, Sprite.HEIGHT );

            return new System.Drawing.Bitmap( ms );
        }

    }
}
