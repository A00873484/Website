﻿using Game_Engine_Team.Texture;

// Andrew Meckling
namespace Game_Engine_Team.Actors
{
    public partial class Enemy
    {
        /// <summary>
        /// Private default enemy constructor.
        /// </summary>
        private Enemy()
            : this( null, null )
        {
        }

        /// <summary>
        /// Builder class for creating enemy objects in batch.
        /// </summary>
        public class Builder
        {
            /// <summary>
            /// The underlying enemy object being built.
            /// </summary>
            private Enemy scaffold;

            /// <summary>
            /// Constructs an instance of the enemy builder.
            /// </summary>
            public Builder()
            {
                scaffold = new Enemy();
            }

            /// <summary>
            /// Finishes constructions and returns an enemy as specified by 
            /// the state of the builder object.
            /// </summary>
            /// <returns>A unique, non-aliased, enemy object.</returns>
            internal Enemy Build()
            {
                return (Enemy) scaffold.Spawn();
            }

            /// <summary>
            /// Sets the projectile emitter for enemy ranged attacks.
            /// </summary>
            /// <param name="e">A projectile emitter.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetEmitter( ProjectileEmitter e )
            {
                scaffold.emitter = e;
                return this;
            }

            /// <summary>
            /// Sets the sprite to be used by the enemy.
            /// </summary>
            /// <param name="s">A sprite.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetSprite( Sprite s )
            {
                scaffold.Sprite = s;
                return this;
            }

            /// <summary>
            /// Sets the action point cost of the enemy's attack.
            /// </summary>
            /// <param name="v">A positive non-zero integer.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetAttackCost( int v )
            {
                scaffold.AttackCost = v;
                return this;
            }

            /// <summary>
            /// Sets the maximum health of the enemy.
            /// </summary>
            /// <param name="v">A positive non-zero integer.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetMaxHealth( int v )
            {
                scaffold.MaxHealth = v;
                return this;
            }

            /// <summary>
            /// Sets the offense stat of the enemy.
            /// </summary>
            /// <param name="v">A positive non-zero integer.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetOffense( int v )
            {
                scaffold.Offense = v;
                return this;
            }

            /// <summary>
            /// Sets the defense state of the enemy.
            /// </summary>
            /// <param name="v">A positive integer.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetDefense( int v )
            {
                scaffold.Defense = v;
                return this;
            }

            /// <summary>
            /// Sets the sight radius of the enemy.
            /// </summary>
            /// <param name="v">A positive number.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetSightRadius( double v )
            {
                scaffold.SightRadius = v;
                return this;
            }

            /// <summary>
            /// Sets the bonus sight radius of the enemy for once it has 
            /// detected a target.
            /// </summary>
            /// <param name="v">A positive number.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetSightRadiusBonus( double v )
            {
                scaffold.SightRadiusBonus = v;
                return this;
            }

            /// <summary>
            /// Sets the navigation mode of the enemy.
            /// </summary>
            /// <param name="t"></param>
            /// <returns>The same builder object.</returns>
            public Builder SetNavigationType( NavigationType t )
            {
                scaffold.NavMode = t;
                return this;
            }

            /// <summary>
            /// Sets whether the enemy has a melee ranged attack.
            /// </summary>
            /// <param name="v">A boolean value.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetHasMelee( bool v )
            {
                scaffold.HasMeleeAttack = v;
                return this;
            }

            /// <summary>
            /// Sets the range of the enemy's ranged attack.
            /// </summary>
            /// <param name="v">A positive integer.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetAttackRange( int v )
            {
                scaffold.AttackRange = v;
                return this;
            }

            /// <summary>
            /// Sets the base action points of the enemy.
            /// </summary>
            /// <param name="v">A positive integer.</param>
            /// <returns>The same builder object.</returns>
            public Builder SetBaseActionPoints( int v )
            {
                scaffold.BaseActionPoints = v;
                return this;
            }
        }
    }
}
