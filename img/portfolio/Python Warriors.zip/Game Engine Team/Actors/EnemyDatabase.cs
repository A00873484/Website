﻿using Game_Engine_Team.Texture;
using System.Collections.Generic;

// Andrew Meckling
namespace Game_Engine_Team.Actors
{
    /// <summary>
    /// Enumerated type of all enemies.
    /// </summary>
    public enum EnemyType
    {
        FireDemon,
        Snake,
        Beholder,
    }

    public partial class Enemy
    {
        /// <summary>
        /// Singleton which provides access to an assortment of predefined 
        /// enemy objects.
        /// </summary>
        public class Database
        {
            /// <summary>
            /// The global instance of the singleton.
            /// </summary>
            private static Database instance;

            /// <summary>
            /// Intializes the database of enemy objects. Only call this after 
            /// Game_Engine_Team.Texture.Textures and 
            /// Game_Engine_Team.Projectiles have been initialized.
            /// </summary>
            public static void Initialize()
            {
                instance = new Enemy.Database();
            }

            /// <summary>
            /// Dictionary of specialized enemy objects.
            /// </summary>
            private Dictionary<EnemyType, Enemy> roster = new Dictionary<EnemyType, Enemy>();

            /// <summary>
            /// Creates and populates an instance of the enemy database.
            /// </summary>
            private Database()
            {
                var builder = new Enemy.Builder()
                    .SetSprite( Textures.Get( SpriteType.SnakeBrownLarge ) )
                    ;

                roster[ EnemyType.Snake ] = builder.Build();

                builder = new Enemy.Builder()
                    .SetSprite( Textures.Get( SpriteType.FireDemon ) )
                    .SetEmitter( Projectiles.Get( ProjectileType.WallOfFire ) )
                    .SetBaseActionPoints( 2 )
                    .SetMaxHealth( 10 )
                    .SetSightRadius( 4 )
                    .SetAttackRange( 3 )
                    .SetHasMelee( false )
                    ;

                roster[ EnemyType.FireDemon ] = builder.Build();

                builder = new Enemy.Builder()
                    .SetSprite( Textures.Get( SpriteType.Beholder ) )
                    .SetEmitter( Projectiles.Get( ProjectileType.RedBeam ) )
                    .SetBaseActionPoints( 3 )
                    .SetAttackCost( 3 )
                    .SetMaxHealth( 10 )
                    .SetSightRadius( 3 )
                    .SetSightRadiusBonus( 3 )
                    .SetAttackRange( 4 )
                    .SetNavigationType( NavigationType.Flying )
                    .SetHasMelee( false )
                    ;

                roster[ EnemyType.Beholder ] = builder.Build();
            }

            /// <summary>
            /// Gets the specified enemy from the database for use on the 
            /// specified dungeon.
            /// </summary>
            /// <param name="type">The enemy type to return.</param>
            /// <param name="stage">The dungeon object the enemy is returned to.</param>
            /// <returns>A non-aliasing enemy object.</returns>
            internal static Enemy Get( EnemyType type, Dungeon stage )
            {
                var enemy = (Enemy) instance.roster[ type ].Spawn();
                enemy.MyType = type;
                enemy.Stage = stage;
                return enemy;
            }

            /// <summary>
            /// Gets the sprite associated with the specified enemy from the 
            /// database.
            /// </summary>
            /// <param name="type">The enemy type whose sprite to return.</param>
            /// <returns>A non-aliasing sprite object.</returns>
            internal static Sprite GetSprite( EnemyType type )
            {
                return instance.roster[ type ].Sprite.Spawn();
            }

        }

    }
}
