﻿using Game_Engine_Team.Texture;
using System;

namespace Game_Engine_Team.Actors
{
    public sealed class Mage : Player
    {

        private TrailProjectileEmitter emitter;

        /// <summary>
        /// Constructs an instance of a user-controlled player.
        /// </summary>
        /// <param name="stage">The Dungeon in which the Player exists.</param>
        /// <param name="sprite">The sprite drawn to represent the Player in the 
        /// gameState world.</param>
        public Mage( Dungeon stage )
            : base( stage, Textures.Get( PlayerType.Mage ), 2 )
        {
            MaxHealth = 9;
            Offense = 5;
            Defense = 1;

            AttackRange = 3;
            HasMeleeAttack = false;

            int damage = CalculateDamage();

            emitter = (TrailProjectileEmitter) Projectiles.Get( ProjectileType.WallOfFire );
            emitter.Damage = damage;
            emitter.HazardDamage = Math.Max( damage / 2, 1 );
            emitter.Lifespan = 3;
            emitter.Range = this.AttackRange;

            //emitter = new TrailProjectileEmitter( AttackRange, 3, damage, Math.Max( damage / 2, 1 ),
            //    Textures.Get( EffectType.FireLarge ),
            //    Textures.Get( EffectType.FireLarge ),
            //    Textures.Get( EffectType.FireSmall ) );
        }

        protected override void RangedAttack( Direction dir )
        {
            Stage.AddParticle( this, "wall of fire", emitter.Emit( this.Position, dir ) );
        }

    }
}
