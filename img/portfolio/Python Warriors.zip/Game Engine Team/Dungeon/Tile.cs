﻿using Controls;
using Game_Engine_Team.Actors;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;
using System;
using System.Diagnostics;

namespace Game_Engine_Team
{

    [DebuggerDisplay( "{Position} -- {GetType().Name}" )]
    public abstract class Tile : IEquatable<Tile>
    {
        public const int SIZE = 32;
        public const int WIDTH = Tile.SIZE;
        public const int HEIGHT = Tile.SIZE;

        public Point Position { get; protected set; }

        public int X { get { return Position.X; } }
        public int Y { get { return Position.Y; } }

        public SmartTexture Texture { get; private set; }

        public Dungeon Stage { get; set; }

        public Tile( int x, int y, SmartTexture texture )
        {
            Position = new Point( x, y );
            Texture = texture != null ? texture.CloneSmart() : null;
        }

        public override int GetHashCode()
        {
            // Very efficient hash function. It is unlikely we will ever have 
            // a dungeon whose width or height is greater than 2^16 (65536).
            return ((ushort) this.Y) | ((ushort) this.X << 16);
        }

        public static explicit operator Point( Tile tile )
        {
            return tile.Position;
        }

        public Actor GetActor()
        {
            return Stage.FindActor( Position );
        }

        public Rectangle GetRekt()
        {
            return new Rectangle(
                Position.X * Tile.WIDTH,
                Position.Y * Tile.HEIGHT,
                Tile.WIDTH,
                Tile.HEIGHT );
        }

        public bool ContainsPixel( Point loc )
        {
            return GetRekt().Contains( new Point( loc.X, loc.Y ) );
        }

        public bool IsInside( Point loc )
        {
            int l = (Position.X * Tile.WIDTH);
            int t = (Position.Y * Tile.HEIGHT);
            int r = l + Tile.WIDTH;
            int b = t + Tile.HEIGHT;

            return loc.X >= l
                   && loc.X < r
                   && loc.Y >= t
                   && loc.Y < b;
        }
        
        public abstract Tile PlaceCopy( int x, int y );

        public abstract bool IsTraversable( NavigationType type );

        public virtual bool IsPassable( NavigationType type )
        {
            if ( !IsTraversable( type ) )
                return false;

            Actor actor = GetActor();
            return actor == null || !actor.IsAlive;
        }

        public Tile AdjacentTile( Direction dir )
        {
            return Stage[ this.Position.Add( dir ) ];
        }

        public virtual bool IsObstruction()
        {
            return !IsTraversable( NavigationType.Ground );
        }

        /// <summary>
        /// spriteBatch must be started before passing.
        /// </summary>
        /// <param name="canvas"></param>
        public virtual void Draw( Canvas canvas, bool editMode = false )
        {
            if ( Texture != null )
                canvas.Draw( Texture, Position );
        }

        public virtual void Update( GameTime gameTime )
        {
            if ( Texture != null )
                Texture.Update( gameTime );
        }

        public abstract ITileProxy GetProxy();


        /// <summary>
        /// Override for rejecting Tiles which would normally be linked.
        /// </summary>
        /// <param name="adjacent">The Tile to evaluate.</param>
        /// <returns>True if the Tile is rejected; false otherwise.</returns>
        protected virtual bool RejectOverride( Tile adjacent )
        {
            return false;
        }

        /// <summary>
        /// Override for accepting Tiles which normally would not be linked.
        /// </summary>
        /// <param name="adjacent">The Tile to evaluate.</param>
        /// <returns>True if the Tile is accepted; false otherwise.</returns>
        protected virtual bool AcceptOverride( Tile adjacent )
        {
            return false;
        }

        public bool LinksTo( Tile adjacent )
        {
            Type myType = this.GetType();
            Type otherType = adjacent.GetType();

            return !RejectOverride( adjacent )
                   && (myType.IsAssignableFrom( otherType )
                        || AcceptOverride( adjacent ));
        }


        public virtual bool Equals( Tile other )
        {
            return this.Position == other.Position
                   && this.Stage == other.Stage
                   && this.Texture == other.Texture;
        }

        public override bool Equals( object other )
        {
            if ( other is Tile )
                return this.Equals( (Tile) other );

            return false;
        }

        public static bool operator !=( Tile a, object b )
        {
            return !(a == b);
        }

        public static bool operator ==( Tile a, object b )
        {
            if ( (object) a == null )
                return b == null;

            return a.Equals( b );
        }

        /// <summary>
        /// Gets or sets a value indicating whether the tile will render 
        /// with knowledge about the tile directly to the NORTH of it.
        /// </summary>
        public virtual bool North { get { return Texture.North; } set { Texture.North = value; } }

        /// <summary>
        /// Gets or sets a value indicating whether the tile will render 
        /// with knowledge about the tile directly to the EAST of it.
        /// </summary>
        public virtual bool East { get { return Texture.East; } set { Texture.East = value; } }

        /// <summary>
        /// Gets or sets a value indicating whether the tile will render 
        /// with knowledge about the tile directly to the SOUTH of it.
        /// </summary>
        public virtual bool South { get { return Texture.South; } set { Texture.South = value; } }

        /// <summary>
        /// Gets or sets a value indicating whether the tile will render 
        /// with knowledge about the tile directly to the WEST of it.
        /// </summary>
        public virtual bool West { get { return Texture.West; } set { Texture.West = value; } }

        /// <summary>
        /// Gets or sets a value indicating whether the tile will render 
        /// with knowledge about the tile directly to the NORTH-EAST of it.
        /// </summary>
        public virtual bool NorthEast { get { return Texture.NorthEast; } set { Texture.NorthEast = value; } }

        /// <summary>
        /// Gets or sets a value indicating whether the tile will render 
        /// with knowledge about the tile directly to the NORTH-WEST of it.
        /// </summary>
        public virtual bool NorthWest { get { return Texture.NorthWest; } set { Texture.NorthWest = value; } }

        /// <summary>
        /// Gets or sets a value indicating whether the tile will render 
        /// with knowledge about the tile directly to the SOUTH-EAST of it.
        /// </summary>
        public virtual bool SouthEast { get { return Texture.SouthEast; } set { Texture.SouthEast = value; } }

        /// <summary>
        /// Gets or sets a value indicating whether the tile will render 
        /// with knowledge about the tile directly to the SOUTH-WEST of it.
        /// </summary>
        public virtual bool SouthWest { get { return Texture.SouthWest; } set { Texture.SouthWest = value; } }
    }

    public class VoidTile : Tile
    {

        public VoidTile( int x, int y )
            : base( x, y, null )
        {
        }

        public override bool IsTraversable( NavigationType type )
        {
            return false;
        }

        public override Tile PlaceCopy( int x, int y )
        {
            throw new System.NotSupportedException();
        }

        public override ITileProxy GetProxy()
        {
            throw new System.NotSupportedException();
        }

        /// <summary>
        /// Does nothing.
        /// </summary>
        public override bool North { get { return false; } set {} }

        /// <summary>
        /// Does nothing.
        /// </summary>
        public override bool East { get { return false; } set {} }

        /// <summary>
        /// Does nothing.
        /// </summary>
        public override bool South { get { return false; } set {} }

        /// <summary>
        /// Does nothing.
        /// </summary>
        public override bool West { get { return false; } set {} }

        /// <summary>
        /// Does nothing.
        /// </summary>
        public override bool NorthEast { get { return false; } set {} }

        /// <summary>
        /// Does nothing.
        /// </summary>
        public override bool NorthWest { get { return false; } set {} }

        /// <summary>
        /// Does nothing.
        /// </summary>
        public override bool SouthEast { get { return false; } set {} }

        /// <summary>
        /// Does nothing.
        /// </summary>
        public override bool SouthWest  { get { return false; } set {} }

    }
    
}
