﻿using Controls;
using Game_Engine_Team.Actors;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;

namespace Game_Engine_Team
{
    public class WallTile : Tile
    {
        public new WallTexture Texture
        {
            get {
                return base.Texture as WallTexture;
            }
        }

        public override ITileProxy GetProxy()
        {
            return new TileProxy<WallType>(
                Textures.Find( this.Texture ),
                ( x, y, type ) => new WallTile( x, y, Textures.Get( type ) )
            );
        }

        public WallTile( int x, int y, WallTexture texture )
            : base( x, y, texture )
        {
        }

        public override Tile PlaceCopy( int x, int y )
        {
            return new WallTile( x, y, Texture );
        }

        protected override bool AcceptOverride( Tile adjacent )
        {
            return adjacent is VoidTile;
        }

        /// <summary>
        /// Indicates whether this tile can moved into. The WallTile override 
        /// always returns false.
        /// </summary>
        /// <returns>False.</returns>
        public override bool IsTraversable( NavigationType type )
        {
            return false;
        }

        public override void Draw( Canvas canvas, bool editMode = false )
        {
            base.Draw( canvas );

            // Draw black region in between chunks of grouped tiles.

            bool east = East && SouthEast;
            bool west = West && SouthWest;

            if ( South && (east || west) )
            {
                Point loc = new Point( X * Tile.WIDTH, Y * Tile.HEIGHT );

                int y = loc.Y + 2 * (Tile.HEIGHT / Sprite.HEIGHT);

                int width = east && west
                            ? Tile.WIDTH
                            : Tile.WIDTH / 2;

                int x = east && !west
                        ? loc.X + Tile.WIDTH / 2
                        : loc.X;

                Rectangle destination = new Rectangle( x, y, width, Tile.HEIGHT );

                Color color = editMode ? new Color( 20, 12, 28, 128 ) : new Color( 20, 12, 28 );

                canvas.DrawRect( destination, color, true );
            }
        }
    }
}
