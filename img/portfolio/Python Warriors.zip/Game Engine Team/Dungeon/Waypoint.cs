﻿using Controls;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Engine_Team
{
    public class Waypoint : IEntity, IEquatable<Waypoint>
    {
        public Point Position { get; private set; }

        public int X { get { return Position.X; } }
        public int Y { get { return Position.Y; } }

        public bool Expired { get; protected set; }

        public Sprite Sprite { get; private set; }

        public Waypoint( int x, int y )
        {
            Position = new Point( x, y );
            Sprite = Textures.Get( EffectType.Waypoint );
        }

        public static implicit operator Point( Waypoint waypoint )
        {
            return waypoint.Position;
        }

        public void Update( GameTime gameTime )
        {
            Sprite.Update( gameTime );
        }

        public void Draw( Canvas canvas )
        {
            canvas.Draw( Sprite, Position );
        }

        public bool Equals( Waypoint other )
        {
            return this.Position == other.Position;
        }

        public override bool Equals( object other )
        {
            if ( other is Waypoint )
                return this.Equals( (Waypoint) other );

            return false;
        }

        public static bool operator !=( Waypoint a, object b )
        {
            return !(a == b);
        }

        public static bool operator ==( Waypoint a, object b )
        {
            if ( (object) a == null )
                return b == null;

            return a.Equals( b );
        }
    }
}
