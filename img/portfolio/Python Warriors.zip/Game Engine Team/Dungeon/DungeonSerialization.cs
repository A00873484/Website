﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Game_Engine_Team
{
    [Serializable]
    public partial class Dungeon : ISerializable
    {
        private DungeonProxy __proxy;

        public void GetObjectData( SerializationInfo info, StreamingContext context )
        {
            DungeonProxy proxy = new DungeonProxy();

            for ( int x = 0 ; x < WIDTH ; ++x )
                for ( int y = 0 ; y < HEIGHT ; ++y )
                    proxy.Grid[ x, y ] = this[ x, y ].GetProxy();

            foreach ( var pair in roster )
                proxy.Enemies.Add( new KeyValuePair<string, EnemyProxy>( pair.Key, pair.Value.GetProxy() ) );

            proxy.PlayerSpawn = playerSpawn;

            info.AddValue( "proxy", proxy, typeof( DungeonProxy ) );
        }


        public Dungeon( SerializationInfo info, StreamingContext context )
            : this()
        {
            __proxy = (DungeonProxy) info.GetValue( "proxy", typeof( DungeonProxy ) );
        }

        [OnDeserialized]
        private void SerializedConstruct( StreamingContext context )
        {
            for ( int x = 0 ; x < WIDTH ; ++x )
                for ( int y = 0 ; y < HEIGHT ; ++y )
                    this[ x, y ] = __proxy.Grid[ x, y ].New( x, y );

            foreach ( var pair in __proxy.Enemies )
                this.InsertEnemy( pair.Value.New( this ), pair.Key );
            
            playerSpawn = __proxy.PlayerSpawn;

            __proxy = null;
        }


        public static void Save( Dungeon dungeon, string name )
        {
            IFormatter formatter = new BinaryFormatter();
            using ( Stream stream = new FileStream( name, FileMode.Create, FileAccess.Write, FileShare.None ) )
            {
                formatter.Serialize( stream, dungeon );
            }
        }

        public static Dungeon Load( string name )
        {
            try
            {
                IFormatter formatter = new BinaryFormatter();
                using ( Stream stream = new FileStream( name, FileMode.Open, FileAccess.Read, FileShare.Read ) )
                {
                    return (Dungeon) formatter.Deserialize( stream );
                }
            }
            catch ( System.Runtime.Serialization.SerializationException ex )
            {
                Console.Error.WriteLine( ex.Message );
                return null;
            }
            catch ( System.IO.FileNotFoundException ex )
            {
                Console.Error.WriteLine( ex.Message );
                return null;
            }
        }

        public static string Serialize( Dungeon dungeon )
        {
            IFormatter formatter = new BinaryFormatter();
            using ( MemoryStream stream = new MemoryStream() )
            {
                formatter.Serialize( stream, dungeon );
                stream.Position = 0;

                return new StreamReader( stream ).ReadToEnd();
            }
        }

        public static Dungeon Deserialize( string data )
        {
            IFormatter formatter = new BinaryFormatter();
            using ( MemoryStream stream = new MemoryStream() )
            {
                new StreamWriter( stream ).Write( data );
                stream.Position = 0;

                return (Dungeon) formatter.Deserialize( stream );
            }
        }

    }

    public static class DungeonExtentions
    {
        public static void Save( this Dungeon dungeon, string name )
        {
            Dungeon.Save( dungeon, name );
        }

        public static void Serialize( this Dungeon dungeon )
        {
            Dungeon.Serialize( dungeon );
        }

    }
}
