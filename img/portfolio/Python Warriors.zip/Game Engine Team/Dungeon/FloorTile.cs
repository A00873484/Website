﻿using Game_Engine_Team.Actors;
using Game_Engine_Team.Texture;
using IronPython.Runtime;
using Microsoft.Xna.Framework;

namespace Game_Engine_Team
{
    public class FloorTile : Tile
    {
        public new FloorTexture Texture
        {
            get {
                return base.Texture as FloorTexture;
            }
        }

        public override ITileProxy GetProxy()
        {
            return new TileProxy<FloorType>(
                Textures.Find( this.Texture ),
                ( x, y, type ) => new FloorTile( x, y, Textures.Get( type ) )
            );
        }

        //protected override bool RejectOverride( Tile adjacent )
        //{
        //    if ( adjacent is FloorTile )
        //        return adjacent.Texture != this.Texture;
        //
        //    return false;
        //}

        public Trap Trap { get; internal set; }


        public FloorTile( int x, int y, FloorTexture texture )
            : base( x, y, texture )
        {
        }

        public override Tile PlaceCopy( int x, int y )
        {
            return new FloorTile( x, y, Texture );
        }

        public override void Update( GameTime gameTime )
        {
            base.Update( gameTime );

            if ( Trap != null )
            {
                Trap.Update( gameTime );
                if ( Trap.Expired )
                    Trap = null;
            }
        }

        public override bool IsTraversable( NavigationType type )
        {
            return type == NavigationType.Ground
                || type == NavigationType.Flying;
        }

        public override bool IsObstruction()
        {
            return false;
        }
    }
}
