﻿using Game_Engine_Team.Texture;

namespace Game_Engine_Team
{
    public class BridgeTile : FloorTile
    {
        public override ITileProxy GetProxy()
        {
            return new TileProxy<FloorType>(
                Textures.Find( this.Texture ),
                ( x, y, type ) => new BridgeTile( x, y, Textures.Get( type ) )
            );
        }

        public BridgeTile( int x, int y, FloorTexture texture )
            : base( x, y, texture )
        {
        }

        public override Tile PlaceCopy( int x, int y )
        {
            return new BridgeTile( x, y, Texture );
        }

        protected override bool AcceptOverride( Tile adjacent )
        {
            if ( adjacent is FloorTile )
                return adjacent.Texture == this.Texture;

            return false;
        }
        
    }
}
