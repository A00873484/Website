﻿using Game_Engine_Team.Actors;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Engine_Team
{
    public partial class Dungeon
    {

        public void InsertTile( Tile tile )
        {
            int x = tile.X;
            int y = tile.Y;

            if ( grid[ x, y ] is FloorTile )
                if ( !(tile is FloorTile) )
                    RemoveEnemyAt( x, y );

            this[ x, y ] = tile;
        }

        public void PlaceTile( int x, int y, Tile tile )
        {
            InsertTile( tile.PlaceCopy( x, y ) );
        }

        public void PlaceFloor( int x, int y )
        {
            FloorTile floor = new FloorTile( x, y, Textures.Get( FloorType.Stone0 ) );

            this[ x, y ] = floor;
        }

        public void PlaceWall( int x, int y )
        {
            WallTile wall = new WallTile( x, y, Textures.Get( WallType.Stone0 ) );

            RemoveEnemyAt( x, y );
            this[ x, y ] = wall;
        }

        public void PlacePit( int x, int y )
        {
            PitTile pit = new PitTile( x, y, Textures.Get( PitType.Empty0 ) );

            RemoveEnemyAt( x, y );
            this[ x, y ] = pit;
        }

        /// <summary>
        /// Updates a tile and its adjacent tiles' awareness of each other for 
        /// rendering properly.
        /// </summary>
        /// <param name="myTile">The tile at the center of the update pattern.</param>
        private void UpdateTileLinkage( Tile myTile )
        {
            int x = myTile.X;
            int y = myTile.Y;

            // Warning: this method is very verbose and is prone to bugs 
            // if manipulated or modified. Do so with caution.
            Tile adjTile = this[ x, y - 1 ];
            myTile.North = myTile.LinksTo( adjTile );
            adjTile.South = adjTile.LinksTo( myTile );

            adjTile = this[ x + 1, y ];
            myTile.East = myTile.LinksTo( adjTile );
            adjTile.West = adjTile.LinksTo( myTile );

            adjTile = this[ x, y + 1 ];
            myTile.South = myTile.LinksTo( adjTile );
            adjTile.North = adjTile.LinksTo( myTile );

            adjTile = this[ x - 1, y ];
            myTile.West = myTile.LinksTo( adjTile );
            adjTile.East = adjTile.LinksTo( myTile );


            // Diagonals.
            adjTile = this[ x - 1, y - 1 ];
            myTile.NorthWest = myTile.LinksTo( adjTile );
            adjTile.SouthEast = adjTile.LinksTo( myTile );

            adjTile = this[ x + 1, y - 1 ];
            myTile.NorthEast = myTile.LinksTo( adjTile );
            adjTile.SouthWest = adjTile.LinksTo( myTile );

            adjTile = this[ x - 1, y + 1 ];
            myTile.SouthWest = myTile.LinksTo( adjTile );
            adjTile.NorthEast = adjTile.LinksTo( myTile );

            adjTile = this[ x + 1, y + 1 ];
            myTile.SouthEast = myTile.LinksTo( adjTile );
            adjTile.NorthWest = adjTile.LinksTo( myTile );


            // Shadow for bridges over pits.
            if ( myTile is PitTile )
                (myTile as PitTile).Covered = this[ x, y - 1 ] is BridgeTile;

            Tile southTile = this[ x, y + 1 ];
            if ( southTile is PitTile )
                (southTile as PitTile).Covered = myTile is BridgeTile;
        }

        public bool IsClearShot( Point from, Point to )
        {
            if ( from.X != to.X && from.Y != to.Y )
                return false;

            foreach ( var tile in TileRange( from, to, 1 ) )
                if ( tile.IsObstruction() )
                    return false;

            return true;
        }

        public double MeasureDistance( Point begin, Point end )
        {
            int x = end.X - begin.X;
            int y = end.Y - begin.Y;

            // include wrapping around the edge in calculation
            if ( this.IsInfiniteWorld )
            {
                int[] costsX = {
                    x,
                    (end.X - Dungeon.WIDTH) - begin.X,
                    (end.X + Dungeon.WIDTH) - begin.X
                };
                x = costsX.Min( n => Math.Abs( n ) );

                int[] costsY = {
                    y,
                    (end.Y - Dungeon.HEIGHT) - begin.Y,
                    (end.Y + Dungeon.HEIGHT) - begin.Y
                };
                y = costsY.Min( n => Math.Abs( n ) );
            }

            return Math.Sqrt( x*x + y*y );
        }

        public IEnumerable<Tile> TileRange( Point begin, Point end,
                                            int offStart = 0, int offEnd = 0 )
        {
            if ( begin == end )
            {
                yield break;
            }
            if ( begin.X == end.X )
            {
                int step = (end.Y < begin.Y) ? -1 : +1;

                int begin_y = begin.Y + (step * offStart);
                int end_y = end.Y + (step * offEnd);

                if ( !ValidateRange( begin_y, end_y, step ) )
                    yield break;

                if ( IsInfiniteWorld )
                    WrapY( ref end_y );

                for ( int y = begin_y ; y != end_y ; RangeStepY( ref y, step ) )
                    yield return this[ end.X, y ];
            }
            else if ( begin.Y == end.Y )
            {
                int step = (end.X < begin.X) ? -1 : +1;

                int begin_x = begin.X + (step * offStart);
                int end_x = end.X + (step * offEnd);

                if ( !ValidateRange( begin_x, end_x, step ) )
                    yield break;

                if ( IsInfiniteWorld )
                    WrapX( ref end_x );

                for ( int x = begin_x ; x != end_x ; RangeStepX( ref x, step ) )
                    yield return this[ x, end.Y ];
            }
        }

        private bool ValidateRange( int begin, int end, int step )
        {
            return (step < 0 ? end > begin : end < begin) || IsInfiniteWorld;
        }

        private void RangeStepX( ref int x, int step )
        {
            if ( IsInfiniteWorld )
                x = WrapX( x + step );
            else
                x += step;
        }

        private void RangeStepY( ref int y, int step )
        {
            if ( IsInfiniteWorld )
                y = WrapY( y + step );
            else
                y += step;
        }

    }
}
