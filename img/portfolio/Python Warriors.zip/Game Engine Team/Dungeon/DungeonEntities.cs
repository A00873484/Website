﻿using Game_Engine_Team.Actors;
using Microsoft.Xna.Framework;
using Python_Team;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Engine_Team
{
    public delegate void RosterAltered( string name, Enemy enemy );

    public partial class Dungeon
    {
        public event RosterAltered EnemyAdded;
        public event RosterAltered EnemyRemoved;

        private List<Waypoint> waypoints = new List<Waypoint>();

        private CompositeKeyDictionary<object, string, Particle> particles = new CompositeKeyDictionary<object,string,Particle>();

        private List<Hazard> hazards = new List<Hazard>();

        private Dictionary<string, Enemy> roster = new Dictionary<string, Enemy>();

        private Point playerSpawn;

        private Player player;

        public Player Player
        {
            get {
                return player;
            }
            set {
                player = value;
                player.CurrentTile = (FloorTile) this[ playerSpawn ];
            }
        }

        public ReadOnlyCollection<Hazard> Hazards
        {
            get {
                return hazards.AsReadOnly();
            }
        }

        public ReadOnlyDictionary<string, Enemy> Roster
        {
            get {
                return new ReadOnlyDictionary<string, Enemy>( roster );
            }
        }

        public Dictionary<string, Enemy>.ValueCollection Enemies
        {
            get {
                return roster.Values;
            }
        }

        public IEnumerable<Actor> Actors
        {
            get {
                if ( Player != null )
                    yield return Player;

                foreach ( var enemy in Enemies )
                    yield return enemy;
            }
        }

        public IEnumerable<IEntity> Entities
        {
            get {
                foreach ( Actor actor in Actors )
                    yield return actor;

                foreach ( Hazard hazard in Hazards )
                    yield return hazard;

                foreach ( Particle particle in particles.Values )
                    yield return particle;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns>True if the player spawn was set.</returns>
        public bool SetPlayerSpawn( int x, int y )
        {
            Tile tile = this[ x, y ];

            // VoidTiles are returned when out of bounds.
            if ( tile is FloorTile )
            {
                // Sometimes IsInfiniteWorld is set.
                playerSpawn = tile.Position;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Finds the Actor at the given location in the Dungeon.
        /// </summary>
        /// <param name="x">The x coordinate in screen-tile space to check.</param>
        /// <param name="y">The y coordinate in screen-tile space to check.</param>
        /// <returns>An Actor object or null if no Actor was found.</returns>
        public Actor FindActor( int x, int y )
        {
            return FindActor( new Point( x, y ) );
        }

        /// <summary>
        /// Finds the Actor at the given location in the Dungeon.
        /// </summary>
        /// <param name="loc">The location in screen-tile-coordinates to check.</param>
        /// <returns>An Actor object or null if no Actor was found.</returns>
        public Actor FindActor( Point loc )
        {
            foreach ( var actor in Actors )
                if ( actor.Position == loc )
                    return actor;
            
            return null;
        }

        public void AddWaypoint( int x, int y )
        {
            Waypoint waypoint = new Waypoint( x, y );

            if ( !waypoints.Contains( waypoint ) )
                waypoints.Add( waypoint );
        }

        public void RemoveWaypoint( int x, int y )
        {
            waypoints.Remove( new Waypoint( x, y ) );
        }

        public void AddParticle( object sender, string key, Particle particle )
        {
            particles[ sender, key ] = particle;
        }

        public void RemoveParticle( object sender, string key )
        {
            particles.Remove( sender, key );
        }

        public void RemoveParticles( object sender )
        {
            particles.RemoveAll( sender );
        }

        public bool AddHazard( Hazard hazard )
        {
            int x = hazard.X;
            int y = hazard.Y;

            foreach ( var haz in Hazards )
                if ( haz.Position == hazard.Position )
                    haz.Expire();

            if ( this[ x, y ] is FloorTile )
            {
                this.hazards.Add( hazard );
                return true;
            }
            return false;
        }

        private string GenerateName( Enemy enemy, string name = null )
        {
            string simpleName;
            name = simpleName = (name ?? enemy.ToString().ToLower());

            for ( int i = 2 ; roster.ContainsKey( name ) ; ++i )
                name = simpleName + i;

            return name.SqueezeSpaces();
        }

        public string AddEnemy( Enemy enemy, string name = null )
        {
            if ( enemy == null )
                return null;

            name = GenerateName( enemy, name );

            roster[ name ] = enemy;

            if ( EnemyAdded != null )
                EnemyAdded( name, enemy );

            return name;
        }

        public bool RemoveEnemyAt( int x, int y )
        {
            return RemoveEnemyAt( new Point( x, y ) );
        }

        public bool RemoveEnemyAt( Point pos )
        {
            Actor actor = FindActor( pos );
            RemoveEnemy( actor );
            return actor != null;
        }

        public void RemoveEnemy( Actor enemy )
        {
            if ( enemy == null )
                return;

            string key = roster.First( kv => kv.Value == enemy ).Key;

            roster.Remove( key );

            if ( EnemyRemoved != null && enemy is Enemy )
                EnemyRemoved( key, (Enemy) enemy );
        }

        public bool RenameEnemy( string oldName, string newName )
        {
            if ( !UserScript.ValidateIdentifier( newName ) )
                return false;

            if ( (oldName != null && newName != null)
                 && roster.ContainsKey( oldName )
                 && !roster.ContainsKey( newName ) )
            {
                roster[ newName ] = roster[ oldName ];
                roster.Remove( oldName );
                return true;
            }
            return false;
        }

        public bool InsertEnemy( Enemy enemy, string name = null )
        {
            int x = enemy.X;
            int y = enemy.Y;

            if ( grid[ x, y ].IsTraversable( enemy.NavMode ) )
            {
                RemoveEnemyAt( x, y );
                AddEnemy( enemy, name );

                return true;
            }
            return false;
        }

        /// <summary>
        /// Places an Actor onto the Dungeon at the specified location. Returns
        /// true if the Actor was able to be placed on the Dungeon, false 
        /// otherwise.
        /// </summary>
        /// <param name="x">The x coordinate to place the Actor at</param>
        /// <param name="y">The y coordinate to place the Actor at</param>
        /// <param name="enemy">The Actor object to place on the Dungeon</param>
        /// <returns>True if the Actor was placed on the Dungeon at the specified
        /// pos; false otherwise (ie, the tile found at that location does
        /// not allow Enemies on it)</returns>
        public bool PlaceEnemy( int x, int y, EnemyType enemy, string name = null )
        {
            return InsertEnemy( (Enemy) Enemy.Database.Get( enemy, this ).PlaceCopy( x, y ), name );
        }

        public bool InsertTrap( Trap trap )
        {
            int x = trap.X;
            int y = trap.Y;

            if ( grid[ x, y ] is FloorTile )
            {
                var floorTile = (FloorTile) grid[ x, y ];

                floorTile.Trap = trap;
                return true;
            }
            return false;
        }

    }
}
