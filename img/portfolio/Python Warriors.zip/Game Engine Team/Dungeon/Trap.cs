﻿using Controls;
using Game_Engine_Team.Actors;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game_Engine_Team
{
    public class Trap : IEntity
    {

        public Sprite Sprite { get; private set; }

        public Point Position { get; private set; }

        public int X { get { return Position.X; } }
        public int Y { get { return Position.Y; } }

        public bool Expired { get; private set; }

        public Trap( int x, int y, Sprite sprite )
        {
            Sprite = sprite;
            Position = new Point( x, y );
        }

        public virtual void Activate( Actor victim )
        {
            victim.TakeDamage( 3 );
            Expire();
        }

        public virtual void Update( GameTime gameTime )
        {
            if ( Sprite != null )
                Sprite.Update( gameTime );
        }

        public virtual void Draw( Canvas canvas )
        {
            if ( Sprite != null )
                canvas.Draw( Sprite, Position );
        }

        public void Expire()
        {
            Expired = true;
        }

    }
}
