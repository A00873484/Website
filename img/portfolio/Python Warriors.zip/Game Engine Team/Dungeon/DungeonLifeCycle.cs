﻿using Controls;
using Game_Engine_Team.Actors;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Engine_Team
{
    public partial class Dungeon
    {

        public void Draw( Canvas canvas )
        {
            foreach ( Tile tile in grid )
                tile.Draw( canvas, EditMode );

            foreach ( IEntity entity in Entities )
                entity.Draw( canvas );

            if ( EditMode )
            {
                foreach ( Waypoint waypoint in waypoints )
                    waypoint.Draw( canvas );

                new Waypoint( playerSpawn.X, playerSpawn.Y ).Draw( canvas );
            }
        }

        public void Update( GameTime gameTime )
        {
            foreach ( Tile tile in grid )
                tile.Update( gameTime );

            foreach ( IEntity entity in Entities )
                entity.Update( gameTime );

            foreach ( Particle particle in particles.Values.ToArray() )
                particle.DeliverEffect( this );

            roster.RemoveValue( e => e.Expired );
            hazards.RemoveAll( h => h.Expired );
            particles.RemoveValue( p => p.Expired );
        }

    }

    public static class DictionaryExtentions
    {
        public static void RemoveAll<K, V>( this IDictionary<K, V> dict, Func<K, V, bool> pred )
        {
            foreach ( var pair in dict.ToArray() )
                if ( pred( pair.Key, pair.Value ) )
                    dict.Remove( pair );
        }

        public static void RemoveValue<K, V>( this IDictionary<K, V> dict, Func<V, bool> pred )
        {
            foreach ( var pair in dict.ToArray() )
                if ( pred( pair.Value ) )
                    dict.Remove( pair.Key );
        }

        public static void RemoveValue<K, V>( this IDictionary<K, V> dict, V match )
        {
            foreach ( var pair in dict.ToArray() )
                if ( pair.Value.Equals( match ) )
                    dict.Remove( pair.Key );
        }
    }
}
