﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Python_Team;
using Controls;
using Game_Engine_Team.Equipment;
using Game_Engine_Team.Texture;
using Microsoft.Xna.Framework.Input;

namespace Game_Engine_Team
{
    public class CharacterEdit : Screen
    {
        /// <summary>
        /// A common denominator of all the possible screen widths and heights,
        /// this is used to place objects relative to the size of the screen
        /// rather than at an absolute position
        /// </summary>
        private const int DENOM = 16;

        private LinkedList<Button> buttons;
        private LinkedList<Button> staticButtons;

        private List<Equipment.Equipment> equips = new List<Equipment.Equipment>();
        private Equipment.Equipment selected;
        private Equipment.Equipment clicked;

        private Equipment.Weapon weap;
        private Equipment.Helmet helm;
        private Equipment.Shirt shirt;
        private Equipment.Leggings legs;
        private Point weapCoords;
        private Point helmCoords;
        private Point shirtCoords;
        private Point legsCoords;

        private Texture2D background;

        private SpriteFont monospace;


        private int currentHP = 0;
        private int currentATK = 0;
        private int currentDEX = 0;
        private int HP_Ratio = 1;
        private int ATK_Ratio = 1;
        private int DEX_Ratio = 1;
        private int EXP = 20;


        public ContentManager Content { get; private set; }

        public CharacterEdit( MainController game )
            : base( game )
        {
            Content = game.Content;

            buttons = new LinkedList<Button>();
            staticButtons = new LinkedList<Button>();
            LoadContent( Content );

            //TODO: set stats ratios based on class here

            equips.Add( Equipment.Equipment.CreateEquipment( Weapons.Assassin_Dagger ) );
            equips.Add( Equipment.Equipment.CreateEquipment( Weapons.Demon_Edge ) );
            equips.Add( Equipment.Equipment.CreateEquipment( Weapons.Iron_Sword ) );
            equips.Add( Equipment.Equipment.CreateEquipment( Weapons.Magic_Stick ) );
            equips.Add( Equipment.Equipment.CreateEquipment( Weapons.Plastic_Knife ) );
            equips.Add( Equipment.Equipment.CreateEquipment( Helmets.Assassin_Mask ) );
            equips.Add( Equipment.Equipment.CreateEquipment( Shirts.Assassin_Cloak ) );
            equips.Add( Equipment.Equipment.CreateEquipment( Pants.Assassin_Tights ) );
        }

        private void LoadContent( ContentManager content )
        {
            monospace = content.Load<SpriteFont>( "Fonts/MonoSpace" );
            background = content.Load<Texture2D>( "Backgrounds/MainMenu" );

            buttons.AddLast( new Button( monospace, "-", Screen.Width * 11 / DENOM, Screen.Height * 4 / DENOM, 25, 25 ) );
            buttons.Last.Value.On_Button_Click += new Button.ButtonClick( HP_DOWN_CLICK );
            buttons.AddLast( new Button( monospace, "+", Screen.Width * 13 / DENOM, Screen.Height * 4 / DENOM, 25, 25 ) );
            buttons.Last.Value.On_Button_Click += new Button.ButtonClick( HP_UP_CLICK );
            buttons.AddLast( new Button( monospace, "-", Screen.Width * 11 / DENOM, Screen.Height * 6 / DENOM, 25, 25 ) );
            buttons.Last.Value.On_Button_Click += new Button.ButtonClick( ATK_DOWN_CLICK );
            buttons.AddLast( new Button( monospace, "+", Screen.Width * 13 / DENOM, Screen.Height * 6 / DENOM, 25, 25 ) );
            buttons.Last.Value.On_Button_Click += new Button.ButtonClick( ATK_UP_CLICK );
            buttons.AddLast( new Button( monospace, "-", Screen.Width * 11 / DENOM, Screen.Height * 8 / DENOM, 25, 25 ) );
            buttons.Last.Value.On_Button_Click += new Button.ButtonClick( DEX_DOWN_CLICK );
            buttons.AddLast( new Button( monospace, "+", Screen.Width * 13 / DENOM, Screen.Height * 8 / DENOM, 25, 25 ) );
            buttons.Last.Value.On_Button_Click += new Button.ButtonClick( DEX_UP_CLICK );

            staticButtons.AddLast( new Button( monospace, "Helm", Screen.Width * 7 / DENOM, Screen.Height * 3 / DENOM, 60, 60 ) );
            staticButtons.AddLast( new Button( monospace, "Top", Screen.Width * 7 / DENOM, Screen.Height * 7 / DENOM, 60, 60 ) );
            staticButtons.AddLast( new Button( monospace, "Legs", Screen.Width * 7 / DENOM, Screen.Height * 11 / DENOM, 60, 60 ) );
            staticButtons.AddLast( new Button( monospace, "Weap", Screen.Width * 9 / DENOM, Screen.Height * 8 / DENOM, 60, 60 ) );
        }
        public override void Update( GameTime gameTime )
        {
            base.Update( gameTime );

            MouseState ms = Mouse.GetState();

            if ( ms.X >= 0 && ms.X < Tile.WIDTH && ms.Y >= 0 && ms.Y < Tile.HEIGHT * equips.Count )
            {
                selected = equips[ ms.Y / Tile.HEIGHT ];
                if ( ms.LeftButton == ButtonState.Pressed )
                {
                    clicked = selected;
                }
            }

            if ( ms.LeftButton == ButtonState.Pressed && clicked != null )
            {
                Button target = getButtonClicked( new Point( ms.X, ms.Y ) );
                if ( target != null )
                {
                    if ( clicked is Weapon && target.Text == "Weap" )
                    {
                        weap = (Weapon)clicked;
                        clicked = null;
                        weapCoords = new Point( target.Location.Center.X - 16, target.Location.Center.Y - 16 );
                        //equip weapon code
                    }
                    else if ( clicked is Helmet && target.Text == "Helm" )
                    {
                        helm = (Helmet)clicked;
                        clicked = null;
                        helmCoords = new Point( target.Location.Center.X - 16, target.Location.Center.Y - 16 );
                        //equip helmet code
                    }
                    else if ( clicked is Shirt && target.Text == "Top" )
                    {
                        shirt = (Shirt)clicked;
                        clicked = null;
                        shirtCoords = new Point( target.Location.Center.X - 16, target.Location.Center.Y - 16 );
                        //equip shirt code
                    }
                    else if ( clicked is Leggings && target.Text == "Legs" )
                    {
                        legs = (Leggings)clicked;
                        clicked = null;
                        legsCoords = new Point( target.Location.Center.X - 16, target.Location.Center.Y - 16 );
                        //equip leggings code
                    }
                }
            }

            foreach ( Button btn in buttons )
                btn.Update();
        }

        public Button getButtonClicked( Point p )
        {
            foreach ( Button btn in staticButtons )
            {
                if ( p.X >= btn.Location.Left && p.X < btn.Location.Right
                    && p.Y >= btn.Location.Top && p.Y < btn.Location.Bottom )
                    return btn;
            }

            return null;
        }

        public override void Draw( Canvas canvas )
        {
            MouseState ms = Mouse.GetState();

            canvas.Draw( background, new Rectangle( 0, 0, Screen.Width, Screen.Height ), Color.White );
            canvas.DrawString( monospace, "Health", new Vector2( Screen.Width * 11 / DENOM, Screen.Height * 3.25f / DENOM ), Color.White );
            canvas.DrawString( monospace, "Attack", new Vector2( Screen.Width * 11 / DENOM, Screen.Height * 5.25f / DENOM ), Color.White );
            canvas.DrawString( monospace, "Dexterity", new Vector2( Screen.Width * 11 / DENOM, Screen.Height * 7.25f / DENOM ), Color.White );
            canvas.DrawString( monospace, "EXP:", new Vector2( Screen.Width * 11 / DENOM, Screen.Height * 2 / DENOM ), Color.White );

            canvas.DrawString( monospace, currentHP.ToString(), new Vector2( Screen.Width * 12 / DENOM, Screen.Height * 4 / DENOM + 4 ), Color.White );
            canvas.DrawString( monospace, currentATK.ToString(), new Vector2( Screen.Width * 12 / DENOM, Screen.Height * 6 / DENOM + 4 ), Color.White );
            canvas.DrawString( monospace, currentDEX.ToString(), new Vector2( Screen.Width * 12 / DENOM, Screen.Height * 8 / DENOM + 4 ), Color.White );
            canvas.DrawString( monospace, EXP.ToString(), new Vector2( Screen.Width * 12 / DENOM, Screen.Height * 2 / DENOM + 4 ), Color.White );

            foreach ( Button btn in buttons )
                btn.Draw( canvas );
            foreach ( Button btn in staticButtons )
                btn.Draw( canvas );

            int offset = 0;
            foreach ( Equipment.Equipment wpn in equips )
                canvas.Draw( wpn.Sprite, new Point( 0, offset++ * Tile.HEIGHT ), true );

            if ( clicked != null )
            {
                canvas.Draw( clicked.Sprite, new Point( ms.X, ms.Y ), true );
            }


            if ( weap != null )
            {
                canvas.Draw( weap.Sprite, weapCoords, true );
            }

            if ( helm != null )
            {
                canvas.Draw( helm.Sprite, helmCoords, true );
            }

            if ( shirt != null )
            {
                canvas.Draw( shirt.Sprite, shirtCoords, true );
            }

            if ( legs != null )
            {
                canvas.Draw( legs.Sprite, legsCoords, true );
            }


            if ( selected != null )
            {
                canvas.DrawString( monospace, selected.Name, new Vector2( 0, Screen.Height * 12 / DENOM ), Color.White );
                canvas.DrawString( monospace, selected.Description, new Vector2( 0, Screen.Height * 13 / DENOM ), Color.White );
                canvas.DrawString( monospace, "Damage: " + selected.Damage.ToString(), new Vector2( 0, Screen.Height * 13.5F / DENOM ), Color.White );
                canvas.DrawString( monospace, "Dexterity: " + selected.Dexterity.ToString(), new Vector2( 0, Screen.Height * 14 / DENOM ), Color.White );
                canvas.DrawString( monospace, "Defense: " + selected.Defence.ToString(), new Vector2( 0, Screen.Height * 14.5F / DENOM ), Color.White );
                canvas.DrawString( monospace, "Health: " + selected.Health.ToString(), new Vector2( 0, Screen.Height * 15 / DENOM ), Color.White );
            }
        }

        private void HP_DOWN_CLICK()
        {
            if ( currentHP > 0 )
            {
                EXP++;
                currentHP -= HP_Ratio;
            }
        }
        private void HP_UP_CLICK()
        {
            if ( EXP > 0 )
            {
                EXP--;
                currentHP += HP_Ratio;
            }
        }
        private void ATK_DOWN_CLICK()
        {
            if ( currentATK > 0 )
            {
                EXP++;
                currentATK -= ATK_Ratio;
            }
        }
        private void ATK_UP_CLICK()
        {
            if ( EXP > 0 )
            {
                EXP--;
                currentATK += ATK_Ratio;
            }
        }
        private void DEX_DOWN_CLICK()
        {
            if ( currentDEX > 0 )
            {
                EXP++;
                currentDEX -= DEX_Ratio;
            }
        }
        private void DEX_UP_CLICK()
        {
            if ( EXP > 0 )
            {
                EXP--;
                currentDEX += DEX_Ratio;
            }
        }
    }
}
