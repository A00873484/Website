﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Engine_Team
{
    /// <summary>
    /// Represents a full character including name, experience, de-serialized character object and a 
    /// de-serialized stage object
    /// 
    /// Created by Morgan Wynne
    /// </summary>
    public class Character
    {
        /// <summary>
        /// Public constructor method
        /// </summary>
        public Character(string CharName, string CharacterObj, string Stage, int StageExp)
        {
            this.CharName = CharName;
            this.CharacterObj = CharacterObj;
            this.Stage = Stage;
            this.StageExp = StageExp;
        }

        /// <summary>
        /// TODO add description
        /// </summary>
        public string CharName { get; set; }
        /// <summary>
        /// TODO add description
        /// </summary>
        public string CharacterObj { get; set; }
        /// <summary>
        /// TODO add description
        /// </summary>
        public string Stage { get; set; }
        /// <summary>
        /// TODO add description
        /// </summary>
        public int StageExp { get; set; }

        /*
        /// <summary>
        /// TODO add description
        /// </summary>
        public int Experience { get; set; }

        /// <summary>
        /// TODO add description
        /// Clarify this name, probably a bad decision
        /// </summary>
        public Actors.Player CharacterPlayer { get; set; }

        /// <summary>
        /// TODO add description
        /// </summary>
        public Dungeon CharacterDungeon { get; set; }
        */
    }
}
